﻿# S2 Windows SDK v1.0

基于 BLE 低功耗蓝牙的 Biovital EP-S2 设备 Windows SDK。

## 目录结构

```
├── include/                   # 头文件
│   ├── ble/                   # 蓝牙连接库接口
│   └── bin_proto/             # 通信协议栈接口
├── lib/
│   └── x64/
│       ├── debug/             # Debug 版库（开发调试用）
│       │   ├── ble_operator.lib
│       │   ├── ble_operator.dll
│       │   └── proto-static.lib
│       └── release/           # Release 版库（发布给最终用户用）
│           ├── ble_operator.lib
│           ├── ble_operator.dll
│           └── proto-static.lib
├── demo/                      # 示例工程
├── doc/                       # 文档
│   └── s2_windows_sdk.md
└── README.md
```

## 环境要求

- Windows 10 或更高版本
- Visual Studio 2022 (v143 工具集)
- Windows 10 SDK

## 快速开始

### 1. 配置头文件路径

在你的 VC++ 项目属性中，将以下路径添加到 `附加包含目录`：

```
$(SolutionDir)..\include\ble
$(SolutionDir)..\include\bin_proto
```

### 2. 链接库文件

在 `附加依赖项` 中添加：

```
..\lib\x64\$(Configuration)\ble_operator.lib
..\lib\x64\$(Configuration)\proto-static.lib
```

并在 `附加库目录` 中添加：

```
..\lib\x64\$(Configuration)
```

### 3. 运行时 DLL

将 `ble_operator.dll` 拷贝到你的 exe 同级目录：

- 开发调试时：拷贝 `lib\x64\debug\ble_operator.dll`
- 发布时：拷贝 `lib\x64\release\ble_operator.dll`

> **重要**：Debug 工程必须用 Debug DLL，Release 工程必须用 Release DLL，不能混用，否则会导致 CRT 冲突。

### 4. 使用授权码

在调用任何 SD K 功能之前，必须先设置授权码：

```cpp
#include "operator_factory.h"

auto factory = ble_operator::OperatorFactory::GetInstance();

// 1. 设置授权码
auto result = factory->SetLicense("你的授权码");
if (result != ble_operator::LicenseResult::kSuccess) {
    return; // 授权失败
}

// 2. 初始化日志
factory->InitLog("app.log");

// 3. 使用 BLE 功能
// ...
```

## Demo 说明

Demo 工程展示了基本的 BLE 设备操作流程：扫描 → 连接 → 枚举服务 → 注册通知 → 数据收发。

编译 Demo 前请确保已填写有效的授权码（在 `demoDlg.cpp` 中搜索 `SetLicense`）。

## 文档

详细 API 文档和使用说明见 `doc/s2_windows_sdk.md`。
