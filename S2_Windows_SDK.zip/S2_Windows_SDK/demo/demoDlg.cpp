﻿
// demoDlg.cpp: 实现文件
//

#include "pch.h"
#include "framework.h"
#include "demo.h"
#include "demoDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CString ConvertStdStringToCString(const std::string& str) {
	int len = MultiByteToWideChar(CP_UTF8, 0, str.c_str(), -1, NULL, 0);
	wchar_t* wstr = new wchar_t[len];
	MultiByteToWideChar(CP_UTF8, 0, str.c_str(), -1, wstr, len);
	CString cStr(wstr);
	delete[] wstr;
	return cStr;
}
// 用于应用程序"关于"菜单项的 CAboutDlg 对话框

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

// 实现
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CdemoDlg 对话框



CdemoDlg::CdemoDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DEMO_DIALOG, pParent)
	, ble_addr_(_T(""))
	, msg_(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CdemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_LOG, edit_log_);
	DDX_Text(pDX, IDC_EDIT_BLE_ADDR, ble_addr_);
	DDX_Text(pDX, IDC_EDIT_MSG, msg_);
}

void CdemoDlg::OnOperateResult(const ble_operator::GattOperateType type, const bool success)
{
	CString str;
	switch (type)
	{
	case ble_operator::GattOperateType::kInitBleDevice:
		str = L"init ble device ";
		break;
	case ble_operator::GattOperateType::kEnumGattService:
		str = L"enum gatt service ";
		break;
	case ble_operator::GattOperateType::kRegDataTransNotify:
		str = L"reg data trans notify ";
		break;
	case ble_operator::GattOperateType::kRegRecvCmdNotify:
		str = L"reg recv cmd notify ";
		break;
	default:
		break;
	}

	if (success)
	{
		str += L"success!";
	}
	else
	{
		str += L"failed";
	}

	PrintLog(str);
}

void CdemoDlg::OnError()
{
}

void CdemoDlg::OnCmdSendResult(const bool success)
{
	CString str = success ? L"success" : L"failed";
	PrintLog(str);
}
#include <afx.h>
#include <stdio.h>

CString ucharToHexCString(uint8_t value)
{
	char hexStr[3];
	// 使用格式化函数将字节转换为十六进制字符串表示，格式为%02X表示两位十六进制大写形式
	sprintf_s(hexStr, "%02X", value);
	return CString(hexStr);
}
void CdemoDlg::OnCmdRecv(const uint8_t* data, int length)
{
	CString str = L"on cmd recv: 0x";
	for (size_t i = 0; i < length; i++)
	{
		str += ucharToHexCString(data[i]);
	}
	PrintLog(str);
}

void CdemoDlg::OnDataRecv(const uint8_t* data, int length)
{
	CString str = L"on data recv: 0x";
	for (size_t i = 0; i < length; i++)
	{
		str += ucharToHexCString(data[i]);
	}
	PrintLog(str);
}

void CdemoDlg::OnBleAdd(ble_operator::BleDeviceInfo info)
{
	CString addr;
	addr.Format(L"%llx", info.ble_addr);
	CString str =
		ConvertStdStringToCString(info.ble_id) +
		L", " + ConvertStdStringToCString(info.name) +
		L", " + ConvertStdStringToCString(info.type) +
		L", " + addr + L", added";
	PrintLog(str);
}

void CdemoDlg::OnBleUpdate(unsigned long long ble_addr, ble_operator::BleDeviceInfo info)
{
	CString addr;
	addr.Format(L"%llx", info.ble_addr);
	CString str =
		ConvertStdStringToCString(info.ble_id) +
		L", " + ConvertStdStringToCString(info.name) +
		L", " + ConvertStdStringToCString(info.type) +
		L", " + addr + L", updated";
	PrintLog(str);
}

void CdemoDlg::OnBleRemove(unsigned long long ble_addr)
{
	CString addr;
	addr.Format(L"%llx", ble_addr);
	CString str = addr + L" has removed";
	PrintLog(str);
}

void CdemoDlg::OnScannerStateChanged(ble_operator::ScannerState state)
{
	switch (state)
	{
	case ble_operator::ScannerState::kNone:
		PrintLog(L"ScannerState::kNone");
		break;
	case ble_operator::ScannerState::kStarted:
		PrintLog(L"ScannerState::kStarted");
		break;
	case ble_operator::ScannerState::kComplete:
		PrintLog(L"ScannerState::kComplete");
		break;
	case ble_operator::ScannerState::kStopped:
		PrintLog(L"ScannerState::kStopped");
		break;
	default:
		break;
	}
}

BEGIN_MESSAGE_MAP(CdemoDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, &CdemoDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &CdemoDlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, &CdemoDlg::OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON4, &CdemoDlg::OnBnClickedButton4)
	ON_BN_CLICKED(IDC_BUTTON5, &CdemoDlg::OnBnClickedButton5)
	ON_BN_CLICKED(IDC_BUTTON6, &CdemoDlg::OnBnClickedButton6)
	ON_BN_CLICKED(IDC_BUTTON7, &CdemoDlg::OnBnClickedButton7)
END_MESSAGE_MAP()


// CdemoDlg 消息处理程序

void CdemoDlg::PrintLog(const CString& log)
{
	CString text;
	GetDlgItemText(IDC_EDIT_LOG, text);
	SetDlgItemText(IDC_EDIT_LOG, log + L"\r\n" + text);
}

BOOL CdemoDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 将"关于..."菜单项添加到系统菜单中。

	// IDM_ABOUTBOX 必须在系统命令范围内。
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// 设置此对话框的图标。  当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标

	// TODO: 在此添加额外的初始化代码
	PrintLog(L"Hello");

	HRESULT hr = CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);

	// 第一步：设置授权码（请将 YOUR_LICENSE_KEY_HERE 替换为从我方获取的授权码）
	auto licenseResult = ble_operator::OperatorFactory::GetInstance()->SetLicense("YOUR_LICENSE_KEY_HERE");
	if (licenseResult != ble_operator::LicenseResult::kSuccess) {
		PrintLog(L"授权失败，请检查授权码是否正确或已过期");
		return TRUE;
	}

	ble_operator::OperatorFactory::GetInstance()->InitLog("123.txt");

	scanner_ = ble_operator::OperatorFactory::GetInstance()->CreateBleScanner(this);

	scanner_->Init();
	//scanner_->RegCompleteCallback([this](const std::list<ble_operator::BleDeviceInfo>& devices_info) {
	//	PrintLog(L"scan complete:");
	//	//for (auto dev_info : devices_info) {
	//	//	std::cout << "bt status changed, dev id = " << dev_info.id
	//	//		<< ", name = " << dev_info.name << ", type = " << dev_info.type << std::endl;
	//	//	auto str = CString::Format()
	//	//}
	//	PrintLog(L"print finished");
	//	//available_scanner->Reset();
	//	});

	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

void CdemoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。  对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void CdemoDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CdemoDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CdemoDlg::OnBnClickedButton1()
{
	// TODO: 在此添加控件通知处理程序代码
	//scanner_->StartScan("Bud", 3);
	scanner_->StartScan(nullptr, 0);
}


void CdemoDlg::OnBnClickedButton2()
{
	// TODO: 在此添加控件通知处理程序代码
	scanner_->StopScan();
}


void CdemoDlg::OnBnClickedButton3()
{
	// TODO: 在此添加控件通知处理程序代码
	GetDlgItemText(IDC_EDIT_BLE_ADDR, ble_addr_);
	auto addr = _tcstoull(ble_addr_, nullptr, 16);
	operator_ = ble_operator::OperatorFactory::GetInstance()->CreateBleGattClient(addr, this);
	operator_->InitBleDevice();
}


void CdemoDlg::OnBnClickedButton4()
{
	// TODO: 在此添加控件通知处理程序代码
	operator_->EnumGattServices();
}


void CdemoDlg::OnBnClickedButton5()
{
	// TODO: 在此添加控件通知处理程序代码
	operator_->RegGattServicesNotify();
}


void CdemoDlg::OnBnClickedButton6()
{
	// TODO: 在此添加控件通知处理程序代码
	int32_t num = 100;
	operator_->SendCmd((char*)(&num), 4);
}


void CdemoDlg::OnBnClickedButton7()
{
	// TODO: 在此添加控件通知处理程序代码
	operator_->Close();
}
