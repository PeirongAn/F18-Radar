﻿
// demoDlg.h: 头文件
//

#pragma once
#include "gatt_opetaror_interface.h"
#include "ble_scanner_interface.h"
#include "operator_factory.h"
#include <memory>

// CdemoDlg 对话框
class CdemoDlg : public CDialogEx , public ble_operator::IGattCallBack, public ble_operator::IBleScannerCallBack
{
// 构造
public:
	CdemoDlg(CWnd* pParent = nullptr);	// 标准构造函数

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DEMO_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV 支持


private:
	std::shared_ptr<ble_operator::IBleScanner> scanner_;
	std::shared_ptr<ble_operator::IGattOperator> operator_;

	void OnOperateResult(const ble_operator::GattOperateType type, const bool success) override;

	void OnError() override;

	void OnCmdSendResult(const bool success) override;
	void OnCmdRecv(const uint8_t* data, int length) override;
	void OnDataRecv(const uint8_t* data, int length) override;


	void OnBleAdd(ble_operator::BleDeviceInfo info) override;
	void OnBleUpdate(unsigned long long ble_addr, ble_operator::BleDeviceInfo info) override;
	void OnBleRemove(unsigned long long ble_addr) override;

	void OnScannerStateChanged(ble_operator::ScannerState state) override;



	void PrintLog(const CString& log);
// 实现
protected:
	HICON m_hIcon;

	// 生成的消息映射函数
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton3();
	afx_msg void OnBnClickedButton4();
	afx_msg void OnBnClickedButton5();
	afx_msg void OnBnClickedButton6();
	afx_msg void OnBnClickedButton7();
	CEdit edit_log_;
	CString ble_addr_;
	CString msg_;
};
