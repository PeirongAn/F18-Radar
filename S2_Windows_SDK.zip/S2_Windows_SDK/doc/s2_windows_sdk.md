# S2 Windows SDK文档

## 简介

此项目为方便开发者快速应用接入S2设备。基于此方案，通过应用可以实现S2设备连接、收发指令及数据等操作，该SDK包含两个类库：

- 蓝牙连接工具库，ble_operator
- Biovital EP-S2通信协议栈，bin_proto

通信协议栈包含：

- 提供蓝牙传输数据包的序列化及反序列化
- 提供实时绘图的模型
- 提供文本格式的蓝牙数据存储

## 蓝牙连接

在Windows SDK中，提供了一个外部的蓝牙连接工具，用户可以选择使用该蓝牙连接工具，或者使用Windows Runtime运行库的代码进行蓝牙设备的连接。

### 引用类库

蓝牙连接库，又名ble_operator，是一个动态连接库。其包含4个头文件，以及一个.lib静态链接资源库，和一个.dll动态资源库。

1. 将4个头文件以及ble_operator.lib放置在一个文件夹中，例如`externals/ble/`。
2. 在CMakeLists.txt中添加对ble_operator库的支持，具体可以看Demo项目。

    ```cmake
    target_include_directories(${PROJECT_NAME} PRIVATE
        ...
        "${PROJECT_SOURCE_DIR}/externals/ble/"
    )

    target_link_libraries(${PROJECT_NAME}
        ...
        "${PROJECT_SOURCE_DIR}/externals/ble/ble_operator.lib"
    )
    ```

3. 将ble_operator.dll拷贝到应用.exe的同级目录中。

### 授权码

SDK采用授权码机制控制使用到期时间，在调用其他接口前必须先设置授权码，否则扫描、连接等功能将不可用。

1. 接口说明

    ```cpp
    enum class LicenseResult {
        kSuccess = 0,       // 授权有效
        kInvalidFormat,     // 授权码格式错误（解密失败）
        kExpired,           // 授权已过期
        kNotSet,            // 未调用 SetLicense
    };

    LicenseResult SetLicense(const std::string& license_key);
    ```

2. 调用顺序

    **SetLicense 必须在所有其他操作之前调用**，完整顺序为：

    ```
    SetLicense → InitLog → CreateBleScanner / CreateBleGattClient
    ```

3. 代码示例

    ```cpp
    #include "operator_factory.h"

    auto factory = ble_operator::OperatorFactory::GetInstance();

    // 第一步：设置授权码
    auto result = factory->SetLicense("你的授权码");
    if (result != ble_operator::LicenseResult::kSuccess) {
        // 授权失败，根据 result 判断原因：
        // kInvalidFormat = 授权码格式错误
        // kExpired = 授权已过期
        return;
    }

    // 第二步：初始化日志
    factory->InitLog("app.log");

    // 第三步：正常使用 BLE 功能
    auto scanner = factory->CreateBleScanner(callback);
    ```

4. 未授权时的行为

    | 场景 | 行为 |
    |------|------|
    | 未调用 SetLicense | CreateBleScanner / CreateBleGattClient 返回 nullptr |
    | 授权码格式错误 | SetLicense 返回 kInvalidFormat |
    | 授权已过期 | SetLicense 返回 kExpired |
    | 授权有效 | 一切正常 |

5. 授权码由我方提供，到期后需联系我方续期获取新的授权码。

### 扫描

在连接蓝牙设备前，需要进行蓝牙的扫描，并通过扫描获取设备的id等信息。

1. 通过工厂方法拿到Scanner，然后开启扫描。

    ```cpp
    #include <memory>

    #include "gatt_operator_interface.h"
    #include "ble_scanner_interface.h"
    #include "operator_factory.h"

    using namespace ble_operator;

    std::shared_ptr<IBleScanner> scanner = nullptr;

    // init the scanner.
    if (scanner == nullptr) {
        scanner = OperatorFactory::GetInstance()->CreateBleScanner();\
        // init the scanner.
        scanner->Init();
        // register the complete scan callback.
        scanner->RegCompleteCallback([this](const std::list<BleDeviceInfo> &device_info) {
            // ...
        });
    }
    ```

2. 初始化scanner以及注册蓝牙扫描结果的回调。

    蓝牙返回的BleDeviceInfo是记录蓝牙设备的基础信息

    ```cpp
    struct BleDeviceInfo {
        std::string name; // 设备名称
        std::string id; // 设备id
        std::string type; // 设备类型
    };
    ```

    这是其中一个Biovital EP-S2的设备信息：

    ```
    name = Biovital EP-S2 50c0f01b186e
    id = BluetoothLE#BluetoothLE2c:33:58:86:30:fc-50:c0:f0:1b:18:6e
    type = 
    ```

    Biovital EP-S2设备的蓝牙名称均以Biovital EP-S2，而id字符串中的后17位即为蓝牙设备的mac地址，在连接中，需要使用到uint64_t的地址，需要做以下转换。mac地址去掉:后按16进制进行拼接即可。

    ```cpp
    uint64_t macAddressToUint64(QString macAddress)
    {
        // 1. 移除所有非十六进制字符（包括冒号、连字符等）
        QString cleaned = macAddress.remove(QRegularExpression("[^0-9A-Fa-f]"));

        // 2. 验证是否为有效的MAC地址长度（12字符 = 6字节）
        if (cleaned.length() != 12) {
            return 0; // 或抛出异常
        }
        
        // 3. 将字符串转换为字节数组
        QByteArray bytes = QByteArray::fromHex(cleaned.toLatin1());
        if (bytes.size() != 6) {
            return 0; // 解析失败
        }
        
        // 4. 将字节按顺序组合为uint64_t
        uint64_t result = 0;
        for (int i = 0; i < 6; ++i) {
            uint8_t byte = static_cast<uint8_t>(bytes[i]);
            result |= static_cast<uint64_t>(byte) << (8 * (5 - i)); // 高位在前
        }
        
        return result;
    }
    ```

    然后在初始化Scanner的代码中注册扫描成功设备的回调代码。具体的代码实现可以参考Demo。

    ```cpp
    scanner->RegCompleteCallback([this](const std::list<BleDeviceInfo> &deviceInfos) {
        mScanning = false; // 标志为停止扫描状态
        for (const auto &e: deviceInfos) {
            scanDevicesReceived(e); // 添加蓝牙设备至集合（注意需要过滤等等）
        }
        // 移除过期的设备
        auto devices = collection->findAllDeviceScanExpired();
        for (auto device, devices) {
            collection->remove(device); 
        }
        emit stateChanged();
    });
    ```

3. 在需要时开始扫描和停止扫描，startScan开启扫描后会在一段时间后自动停止。

    ```cpp
    // 开始扫描
    scanner->StartScan();

    // 结束扫描
    scanner->StopScan();
    ```

### 连接及初始化

1. 了解设备操作必须的两个类IGattCallback和IGattOperator。

    ```cpp
    enum class GattOperateType {
        kInitBleDevice = 0, // 连接及初始化设备
        kEnumGattService, // 枚举所有可用的服务
        kRegRecvCmdNotify, // 打开cmd通道（BDF3）的通知回调
        kRegDataTransNotify, // 打开data通道（BDF4）的通知回调
    }

    class IGattCallback {
    public:
        virtual ~IGattCallback() = default;
        
        // 操作是否成功的回调。
        virtual void OnOperateResult(const GattOperateType, const bool success) = 0;
        
        virtual void OnError() = 0;
        
        // 发送命令是否成功的回调
        virtual void OnCmdSendResult(const bool success) = 0;
        // 命令通道收到数据的回调
        virtual void OnCmdRecv(const uint8_t* data, int length) = 0;
        // 数据通道收到数据的回调
        virtual void OnDataRecv(const uint8_t* data, int length) = 0;
    };

    class IGattOperator {
    public:
        virtual ~IGattOperator() = default;
        
        // 初始化蓝牙设备
        virtual bool InitBleDevice() = 0;
        // 枚举Gatt Services服务.
        virtual bool EnumGattServices() = 0;
        // 打开通知回调
        virtual bool RegGattServicesNotify() = 0;
        // 发送命令数据
        virtual bool SendCmd(const char* data, const int length) = 0;
        // 关闭设备
        virtual bool Close() = 0;
    };
    ```

    框架将蓝牙指令封装成若干个函数，每一个函数与若干个函数相对应。

2. 自定义一个类实现IGattCallback中的回调，例如MGattCallback。

    ```cpp
    class MGattCallback: public IGattCallback {
    public:
        MGattCallback(QString macAddress, BleServiceLocal *serviceLocal);
        
        virtual void OnOperateResult(const GattOperateType type, const bool success) override {
            // ...
        }
        
        virtual void OnError() override {
        }
        
        virtual void OnCmdSendResult(const bool success) override {
        }
        
        virtual void OnCmdRecv(const uint8_t *data, int length) override {
            dynamic_array<char> d(length);
            d.copy_from((char *) data);
            // ...
        }
        
        virtual void OnDataRecv(const uint8_t *data, int length) override {
            dynamic_array<char> d(length);
            d.copy_from((char *) data);
            // ...
        }
        
    private:
        QString macAddress;
        BleServiceLocal *serviceLocal = nullptr;
    }
    ```

3. 用户扫描完成后，需要通过之间获得的地址创建IGattOperator对象，然后进行初始化操作（包含了设备连接）。假设我们需要连接的设备地址为QString类型的address，如何获取可以看前文。

    ```
    uint64_t addr = macAddressToUint64(address); // 将蓝牙地址转换成uint64_t
    std::shared_ptr<IGattCallback> callback = std::make_shared<MGattCallback>(address, this);
    // operator是保留关键字
    std::shared_ptr<IGattOperator> optor = OperatorFactory::GetInstance()->CreateBleGattClient(addr, callback.get());
    optor->InitBleDevice();
    // 重置notificationSpin值，用于判断打开通知是否成功。
    handle->notificationSpin = 0;
    ```

4. 当用户初始化完成并且成功时，发现设备服务。

    ```cpp
    // 回调
    virtual void OnOperateResult(const GattOperateType type, const bool success) override {
        // ...
        if (type == GattOperateType::kInitBleDevice) {
            if (!success) {
                // 断开设备连接
            } else {
                // 这里进行discoverService的操作
                optor->EnumGattServices();
            }
        }
    }
    ```

5. 当设备发现服务后，打开两个通道的通知回调（Notification）。

    ```cpp
    // 回调
    virtual void OnOperateResult(const GattOperateType type, const bool success) override {
        // ...
        else if (type == GattOperateType::kEnumGattService) {
            if (!success) {
                // 断开设备连接
            } else {
                // 这里进行discoverService的操作
                optor->EnumGattServices();
            }
        }
    }
    ```

6. 当打开通知完成后，设备便准备就绪，等待数据交换。

    ```
    // 回调
    virtual void OnOperateResult(const GattOperateType type, const bool success) override {
        // ...
        else if (type == GattOperateType::kRegRecvCmdNotify || type == GattOperateType::kRegDataTransNotify) {
            if (!success) {
                // 断开设备连接
            } else {
                handle->notifictionSpin += 1;
                if (handle->notificationSpin == 2) {
                    // 设备准备就绪。
                }
            }
        }
    }
    ```

### 初始化请求

当设备初始化完成之后，需要结合蓝牙SDK创建好数据处理器（用于数据包的序列化以及反序列化）

1. 创建数据接收回调器，用于接收响应数据。

    ```cpp
    class my_processor_callback: public bin_pack_processor_callback {
    public:
        virtual void send_failure(std::string msg) override {
            // 编写发送失败时的回调，如打印错误日志等。
        }
        
        virtual void received_failure(std::string msg) override {
            // 编写接收失败时的回调，如打印错误日志等。
        }
        
        virtual void received(std::shared_ptr<bin_data> data) override {
            // 接收数据时的回调。
            if (data == nullptr) {
                return;
            }
            
            // 获取对应的op_code，即操作码。
            auto op_code = data->get_op_code();
            switch (op_code) {
            case query_firmware_version:
                auto resp = std::reinterpret_pointer_cast<query_firware_version_response>(data);
                // 进行业务数据的处理。
                break;
            }
        }
    };
    ```

2. 创建两个数据接收回调器实例，分别用于命令通道的数据接收和数据通道的数据接收。

    ```cpp
    std::shared_ptr<my_processor_callback> callback = std::make_shared<my_processor_callback>(this);

    std::shared_ptr<bin_pack_processor> cmd_processor = nullptr;
    std::shared_ptr<bin_pack_processor> data_processor = nullptr;
    cmd_processor = std::make_shared<bin_pack_processor>();
    cmd_processor->mtu = 256; // windows系统默认使用256。
    cmd_processor->callback = callback;
    data_processor = std::make_shared<bin_pack_processor>();
    data_processor->mtu = 256;
    data_processor->callback = callback;
    ```

3. 连接数据响应以及数据接收回调器。

    回到之前[连接及初始化](#_5)的代码段：

    ```cpp
    class MGattCallback: public IGattCallback {
    public:
        MGattCallback(QString macAddress, BleServiceLocal *serviceLocal);
        
        virtual void OnOperateResult(const GattOperateType type, const bool success) override {
            // ...
        }
        
        virtual void OnError() override {
        }
        
        virtual void OnCmdSendResult(const bool success) override {
        }
        
        virtual void OnCmdRecv(const uint8_t *data, int length) override {
            dynamic_array<char> d(length);
            d.copy_from((char *) data);
            // 直接传递给cmd_processor即可。
            cmd_processor->add_package(std::move(d));
        }
        
        virtual void OnDataRecv(const uint8_t *data, int length) override {
            dynamic_array<char> d(length);
            d.copy_from((char *) data);
            // 直接传递给data_processor即可。
            data_processor->add_package(std::move(d));
        }
        
    private:
        QString macAddress;
        BleServiceLocal *serviceLocal = nullptr;
    }
    ```

4. 完善数据接收回调器，对每一种请求做一定的数据响应。

    ```cpp
    class my_processor_callback: public bin_pack_processor_callback {
    public:
        virtual void send_failure(std::string msg) override {
            // 编写发送失败时的回调，如打印错误日志等。
        }
        
        virtual void received_failure(std::string msg) override {
            // 编写接收失败时的回调，如打印错误日志等。
        }
        
        virtual void received(std::shared_ptr<bin_data> data) override {
            // 接收数据时的回调。
            if (data == nullptr) {
                return;
            }
            
            // 获取对应的op_code，即操作码。
            auto op_code = data->get_op_code();
            switch (op_code) {
            case query_firmware_version:
                auto resp = std::reinterpret_pointer_cast<query_firmware_version_response>(data);
                dispatch_query_firmware_version(resp);
                break;
            }
        }
    private:
        void dispatch_query_firmware_version(std::shared_ptr<query_firmware_version_response> resp) {
            // 在这里进行业务处理。
        }
    };
    ```

5. 创建请求并发送数据。

    ```cpp
    // 辅助函数
    void send_proto(std::shared_ptr<bin_data> proto) {
        auto send_packages = cmd_processor->build_send_packages(proto);
        auto data = std::move(send_packages[0]);
        // IGattOperator
        optor->SendCmd(data.begin(), data.length());
    }

    // 构建请求并发送
    auto request = std::make_shared<query_firmware_version_request>();
    send_proto(request);
    ```

6. 要完成设备的初始化，应当依次进行下列请求。

    - query_firmware_version_request：查询设备固件版本号。
    - query_sci_sensor_info_request：查询传感器参数信息。
    - query_ecg_channel_request：查询ECG外部通道开关。

### 蓝牙连接框架集成

蓝牙连接工具提供了基础的蓝牙连接、初始化、数据通信功能。用户在必要时需要在此基础上做进一步封装，目前Demo封装成了几个模块。

    - BleService：蓝牙服务抽象，提供了蓝牙的原子操作函数。
    - BleServiceCollection：蓝牙服务集合，用于支持多通道的蓝牙实现。（无关）
    - BleServiceLocal：兼容ble_operator的本地蓝牙实现。
    - BleServiceRemote：提供蓝牙网关Cassia蓝牙实现。（无关）
    - BleDevice：设备抽象，通过BleService进行蓝牙操作。
    - BleDeviceCollection：设备集合。

### 蓝牙资源标识符

BiovitalS2设备使用BLE，即低功耗蓝牙传输协议进行通信。在BLE的传输协议中，资源的定义分为三级：Service（服务）、Characteristic（特征）、Descriptor（描述符）。

!!! info "蓝牙资源Uuid"
    三者均使用Uuid作为资源的唯一标识，在蓝牙协议中，资源Uuid的大部分都是相同的，均可以用0000XXXX-0000-1000-8000-00805F9B34FB标识。

Characteristic是数据传输的通道，根据数据的传输方式分为三种类型：Read（读取）、Write（写入）和Notification（主动推送）。

在BiovitalS2的协议中，目标Service的Uuid为BDF0（简写），其中有四个Characteristic：

- BDF1：命令发送通道
- BDF2：保留
- BDF3：命令接收通道
- BDF4：数据接收通道

## 蓝牙数据包的序列化和反序列化

当打开蓝牙通道时，能够以二进制的形式发送数据包，并且每包发送的字节数量不大于MTU的限制，因此在传输较大的数据时，需要进行分包的处理。

该C++协议层封装了数据包解析的过程，用于数据包的序列化以及反序列化。

### 发送数据包

1. 创建`bin_pack_processor`，并且初始化`mtu`为蓝牙协议的mtu值。
2. 构建需要发送的请求，这里以发送请求设备硬件版本号为例。
3. 调用`build_send_packages`方法构建需要发送的字节序列。
4. 依次向蓝牙传输层发送多个数据包。

```cpp
#include <memory>
#include "bin_protos_io.h"
#include "bin_protos.h"

std::shared_ptr<bin_pack_processor> processor = std::make_shared<bin_pack_processor>();
processor->mtu = ...; // 在这里填写实际的mtu值。
std::shared_ptr<query_firmware_request> request = std::make_shared<query_firmware_request>();
// 填充请求的字段，由于这个请求没有字段，不填。

std::vector<dynamic_array<char>> packages = processor->build_send_packages(request);

for (auto package: packages) {
    // 这里发送蓝牙数据。
    bluetooth.send(std::move(package));
}
```

### 接收数据包

对于命令接收通道BDF3和数据接收通道BDF4，进行以下的流程：

1. 创建bin_pack_processor，并且初始化mtu为蓝牙协议的mtu值。
2. 创建一个类，继承bin_pack_processor_callback，用于接收协议的回调。（回调可以在两个接受通道中复用。）
3. 设置回调。
4. 当通道接收到数据时，调用add_package方法将数据添加到processor。
5. 在回调中进行业务逻辑的处理。

```cpp
#include <memory>
#include "bin_protos.io.h"
#include "bin_protos.h"

std::shared_ptr<bin_pack_processor> processor = std::make_shared<bin_pack_processor>();
processor->mtu = ...; // 在这里填写实际的mtu值。

class my_processor_callback: public bin_pack_processor_callback {
public:
    virtual void send_failure(std::string msg) override {
        // 编写发送失败时的回调，如打印错误日志等。
    }
    
    virtual void received_failure(std::string msg) override {
        // 编写接收失败时的回调，如打印错误日志等。
    }
    
    virtual void received(std::shared_ptr<bin_data> data) override {
        // 接收数据时的回调。
        if (data == nullptr) {
            return;
        }
        
        // 获取对应的op_code，即操作码。
        auto op_code = data->get_op_code();
        switch (op_code) {
        case query_firmware_version:
            auto resp = std::reinterpret_pointer_cast<query_firware_version_response>(data);
            // 进行业务数据的处理。
            break;
        }
    }
};

processor->callback = std::make_shared<my_processor_callback>();

// 接收到数据包时
processor->add_package(data);
```

### 数组类dynamic_array

dynamic_array时用于封装数组的类型，其内部结构为数组指针和数组的长度。数组类不可拷贝。

## 实时绘图模型

bin_proto_model.h头文件中的类用于实现实时绘图模型，其能够存储实时绘图的数据，用户仅需要创建控件（例如Qt中的qcustomplot.h）并且覆盖部分回调方法便可以实现实时图形的绘制。

以下是该文件涉及到的类型及说明：

1. sensor_type：传感器类型，对应绘图中的图表。
2. sensor_color：波形的颜色。
3. sensor_dimension：传感器维度，对于加速度传感器而言，其具有ax、ay、az三个维度。
4. sensor_label：图表的标签，有传感器类型，标签名，维度三个属性。
5. point_2d：数据点
6. sensor_value_transformer：从原始ADC值转换成实际值的转换器。
7. graph_comp_creator：创建sensor_label和graph_page的构造器。
8. data_summary：数据平均值等统计值。
9. ⭐graph_page：图表实体类。
10. ⭐graph_model：图表集合的实体类。
11. ⭐graph_model_adapter：图表集合的适配器类。

我们先假设用户创建了一个用于绘制波形的控件类wave_table：

要实现波形绘制，需要进行以下几个步骤：

1. 创建必要的实体类。

    ```cpp
    std::shared_ptr<graphic_model> model = std::shared_ptr<graphic_model>();
    std::shared_ptr<sensor_value_transformer> transformer = std::make_shared<sensor_value_transformer>();
    std::shared_ptr<graphic_model_adapter> adapter = std::make_shared<graphic_model_adapter>(model, transformer);;
    ```

2. 创建wave_table的容器，并创建控件。

    ```cpp
    std::vector<sensor_type> sensor_types_in_wave_table() {
        return {
            sensor_type::acceleration,
            // ...
        }
    }

    std::map<sensor_type, wave_table *> tables;

    auto sensor_types = sensor_types_in_wave_table();
    int number = 1;
    for (auto sensor_type: sensor_types) {
        wave_table *table = new wave_table();
        table->sensor_type = sensor_type;
        table->number = number++;
        
        tables[table->sensor_type] = table;
    }
    ```

3. 图表和实体模型进行绑定。

    ```cpp
    auto sensor_types = sensor_types_in_wave_table();
    for (auto sensor_type: sensor_types) {
        wave_table *table = tables[sensor_type];
        table->set_bind_page(model->page_of(sensor_type));
    }
    ```

4. 当接收到数据时，向adapter中推送数据。

    ```cpp
    // device is a bluetooth_device, and dispatch the data.
    void device::dispatch_common_data(std::shared_ptr<common_data_response> resp) {
        adapter->push_data(resp);
    }
    ```

5. 在wave_table中的set_bind_page方法中，去实现graph_page的回调方法。

    ```cpp
    void wave_table::set_bind_page(std::shared_ptr<graphic_page> page) {
        if (bind_page == page) {
            return;
        }
        
        // 将之前绑定的函数移除
        if (bind_page != nullptr) {
            bind_page->label_changed = nullptr;
            bind_page->data_pushed = nullptr;
            bind_page->data_changed = nullptr;
            // 重置wave_table
            reset_wave_table();
        }
        
        bind_page = page;
        if (page != nullptr) {
            // 适配graphic_page与wave_table.
            adapt_graphs(page);
            // 标签更改时的方法回调
            page->label_changed = [=] (std::shared_ptr<sensor_label>) {
                adapt_graphs(bind_page);
            }
            // 接收到数据时的回调，其中第一个是第index维的数据，第二个是数据的点集。
            page->data_pushed = [=] (int index, std::vector<point_2d> &points) {
                push_data(index, points);
            }
            // 数据更改时的回调，一般用于刷新图表等。
            page->data_changed = [=] {
                refresh_data();
            }
        }
    }

    void wave_table::adapt_graphs(std::shared_ptr<graphic_page> page) {
        int dimension = page->label->dimensions.size();
        // customPlot, qt中的图表控件。
        QCustomPlot *plot = ui->wavePlot;
        int existed_dimension = plot->graphCount();
        for (int i = existed_dimension; i < dimension; ++i) {
            plot->addGraph();
            plot->graph(i)->setLineStyle(QCPGraph::lsLine);
            plot->graph(i)->setPen(QPen(sensor_color_v(page->label->dimensions[i]->color), 2));;
        }
    }

    void wave_table::push_data(int index, std::vector<point> &points) {
        QCustomPlot *plot = ui->wavePlot;
        if (index >= plot->graphCount()) {
            return;
        }
        for (const auto &e : points) {
            QCPGraph *graph = plot->graph(index);
            graph->addData(e.x, e.y);
        }
        
        auto last = points.back();
        mCurrentLastAxisX = last.x;
        
        waveTimeTicker->setBaseSecondsSinceEpoch((long) bindPage->startOffset);
        refresh_axis_x();
    }

    void wave_table::refresh_data() {
        clear_wave_table_cache();
        
        ui->wavePlot->yAxis->rescale(true);
        ui->wavePlot->replot();
    }
    ```

## 文件存储

bin_protos_save.h中的类用于进行文件的存储，存储的格式默认为csv格式，即和腕表本地保存的文本格式相同，该库暂不支持以二进制的方式保存数据。

以下是该文件中涉及到的类文件及说明：

1. save_file_system：文件系统，用于给保存提供必要的信息。
2. text_writer：用于写入文本数据。
3. date_hour_token：文件的保存方式是按照日期-小时来分文件保存的，用于判断保存文件的标识符。
4. alg_part_model：算法数据保存时需要拆分成两个文件。
5. bin_save_transaction：文件保存会话。

要实现文件保存，需要进行以下几个步骤：

1. 重写save_file_system和text_writer，并且实现其中的几个纯虚函数。

    ```cpp
    class m_file_system: public save_file_system {
    public:
        virtual std::string seperator() override {
            return "\\"
        }
        
        virtual std::string get_base_dir(const std:string &deivce_mac_address) override {
            // 存放在一个目录中。
        }
        
        virtual std::shared_ptr<text_writer> create_writer(const std::string &file_path, bool append = false) override {
            return std::make_shared<m_text_writer>(QString::fromStdString(file_path), append);
        }
        
        virtual int time_seconds_between() override {
            return 60;
        }
    };

    class m_text_writer: public text_writer {
    public:
        m_text_writer(QString file_path, bool append = false) {
            internalFile = new QFile(file_path);
            FileIO::createDir(QFileInfo(filePath).dir().absolutePath());
            if (!append) {
                if (!internalFile->open(QFile::WriteOnly)) {
                    qDebug() << "create MTextWriter failed.";
                }
            } else {
                if (!internalFile->open(QFile::Append)) {
                    qDebug() << "create MTextWriter append failed.";
                }
            }
        }
        
        virtual bool write_text(const std::string &text) override {
            internalFile->write(QString::fromStdString(text).toUtf8());
            return true;
        }
        
        virtual bool close() override {
            internalFile->close();
            internalFile = nullptr;
            return true;
        }
        
    private:
        QFile *internalFile = nullptr;
    }
    ```

2. 当需要保存数据时，创建save_transaction并写入数据。

    ```cpp
    void device::dispatch_common_data(std::shared_ptr<common_data_response> resp) {
        adapter->push_data(resp);
        if (mSavingState == SavingState::Saving) {
            if (!resp->data_points.empty()) {
                long time_seconds = resp->data_points[0]->time_milliseconds / 1000L;
                // 当没有transaction时，应当创建。
                if (saveTransaction = nullptr) {
                    std::shared_ptr<m_file_system> file_system = get_file_system();
                    saveTransaction = std::make_shared<bin_save_transaction>(time_seconds, mMacAddress.toStdString(), fileSystem);
                }
                saveTransaction->push_data(resp);
            }
        }
    }
    ```

3. 当需要停止保存数据时，关闭save_transaction。

    ```cpp
    void device::stop_save() {
        if (mSavingState == SavingState::Saving) {
            mSavingState = SavingState::NotSave;
            if (saveTransaction != nullptr) {
                saveTransaction->stop_transaction();
                saveTransaction = nullptr;
            }
            stateChanged();
        }
    }
    ```

## 蓝牙网关Cassia

蓝牙网关Cassia使用了http协议对蓝牙的协议进行了分装，蓝牙网关的具体使用方法可以见官方文档：

[https://github.com/CassiaNetworks/CassiaSDKGuide/wiki](https://github.com/CassiaNetworks/CassiaSDKGuide/wiki)

### 启动项配置

BiovitalCassia项目可以使用启动项配置文件在软件启动时读取配置并：

1. 连接并初始化网关。
2. 在连接网关后，对每个网关配置的设备进行设备连接、采集和保存的操作。

BiovitalCassia启动项配置文件放置在目录`/config/runner.json`下，下面是示例文件：

```json
{
    "cassias": [
        {
            "address": "192.168.1.1",
            "devices": [
                {
                    "macAddress": "65:F3:CD:21:50:CD",
                    "capture": true,
                    "save": true
                }
            ]
        }
    ]
}
```

第一级"cassias"是网关配置的数据，"address"表示网关地址，可以简写（默认以http://协议填充），"devices"表示要连接的设备列表。

在设备列表中，"macAddress"表示要连接设备的mac地址，"capture"表示在设备连接之后是否开启采集功能，"save"表示设备连接之后是否开启文件保存功能。

### Kafka消息队列

topic：biovital-data-\*

软件采集到的数据将通过kafka消息队列同步发出，每种数据类型分别占用一个topic，格式为biovital-data-*，例如六轴为biovital-data-imu，具体的数据类型可以参考[数据tag和文件夹tag](./s2_storage_protocol.md/#tagtag)中**数据tag**一列。

下面是imu数据的数据示例，数据以json文本（压缩）的格式进行传输。其中type字段表示数据的类型，device表示设备的mac地址，并以小写的十六进制显示，datas为所有数据点的序列，timestamp表示毫秒级的数据时间戳，datas表示数据，并使用了**标准单位**一列作为单位。

```json
{
    "type": "imu",
    "device": "65f3cd2150cd",
    "datas": [
        {
            "timestamp": 1742263914050,
            "datas": [7.83, 0.07, 2.10, 18.32, 11.03, -0.35],
        }
    ]
}
```

和表格中有区别的几个数据格式：

hrv：datas中包含两个数据，其中第一个是rr间期，第二个是hrv，两者单位均为ms。

alg：算法分析数据，其中第一列为心率（bpm），第二列为血氧（spO2）。

目前支持的所有数据格式有：

imu、emg、ppg_green、ppg_red_ir、eda、skin_temp、epa、eht、device_temp、light、magn、alg、hrv。

### Kafka-Broker配置

Kafka需要使用Broker来将生产者的数据传递给消费者，以本机为例，讲解如何进行Kafka-Broker的配置。

在BiovitalCassia项目中，要修改Broker的地址，可以在config/config.ini文件中添加一行，需要注意的是，当Kafka配置更改时，你需要重启应用才能应用修改的配置：

brokers=\[brokerAddress\]，例如

```
brokers="localhost:19092,localhost:19093,localhost:19094"
```

在本机中，可以安装一个Docker Desktop，然后开启docker来作为本机的Kafka-Broker。

示例的docker-compose.yml文件如下：

```yml
#kafka的image版本若为最新，则改为image: confluentinc/cp-kafka:latest
version: '3'

services:
  zookeeper:
    image: confluentinc/cp-zookeeper:latest
    hostname: zookeeper
    container_name: zookeeper
    ports:
      - "2181:2181"
    environment:
      ZOOKEEPER_CLIENT_PORT: 2181
      ZOOKEEPER_TICK_TIME: 2000
    networks:
      - kafka-net

  kafka-broker1:
    image: confluentinc/cp-kafka:7.4.1
    hostname: kafka-broker1
    container_name: kafka-broker1
    depends_on:
      - zookeeper
    ports:
      - "19092:19092"
    environment:
      KAFKA_BROKER_ID: 1
      KAFKA_ZOOKEEPER_CONNECT: zookeeper:2181
      KAFKA_LISTENER_SECURITY_PROTOCOL_MAP: PLAINTEXT:PLAINTEXT,EXTERNAL:PLAINTEXT
      KAFKA_LISTENERS: PLAINTEXT://:9092,EXTERNAL://:19092
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka-broker1:9092,EXTERNAL://localhost:19092
      KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 3
      KAFKA_DEFAULT_REPLICATION_FACTOR: 3
    networks:
      - kafka-net


  kafka-broker2:
    image: confluentinc/cp-kafka:7.4.1
    hostname: kafka-broker2
    container_name: kafka-broker2
    depends_on:
      - zookeeper
    ports:
      - "19093:19093"
    environment:
      KAFKA_BROKER_ID: 2
      KAFKA_ZOOKEEPER_CONNECT: zookeeper:2181
      KAFKA_LISTENER_SECURITY_PROTOCOL_MAP: PLAINTEXT:PLAINTEXT,EXTERNAL:PLAINTEXT
      KAFKA_LISTENERS: PLAINTEXT://:9092,EXTERNAL://:19093
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka-broker2:9092,EXTERNAL://localhost:19093
      KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 3
    networks:
      - kafka-net

  kafka-broker3:
    image: confluentinc/cp-kafka:7.4.1
    hostname: kafka-broker3
    container_name: kafka-broker3
    depends_on:
      - zookeeper
    ports:
      - "19094:19094"
    environment:
      KAFKA_BROKER_ID: 3
      KAFKA_ZOOKEEPER_CONNECT: zookeeper:2181
      KAFKA_LISTENER_SECURITY_PROTOCOL_MAP: PLAINTEXT:PLAINTEXT,EXTERNAL:PLAINTEXT
      KAFKA_LISTENERS: PLAINTEXT://:9092,EXTERNAL://:19094
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka-broker3:9092,EXTERNAL://localhost:19094
      KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 3
    networks:
      - kafka-net

networks:
  kafka-net:
    driver: bridge
```

同时，可以写一个Kakfa-Consumer的程序去消费消息队列中的信息，同时检验Kafka-Producer是否正常工作。