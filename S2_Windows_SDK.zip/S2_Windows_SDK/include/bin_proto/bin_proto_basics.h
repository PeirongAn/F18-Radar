#ifndef BIN_PROTO_BASICS_H
#define BIN_PROTO_BASICS_H

#include <sstream>

/// @brief wrapper for dynamic array, removes copy constructor.
/// @tparam T 
template <typename T>
class dynamic_array
{
public:
    dynamic_array()
    {
        _pointer = nullptr;
        _length = 0;
    }

    dynamic_array(size_t length)
    {
        _pointer = new T[length];
        _length = length;
    }

    dynamic_array(T *pointer, size_t length)
    {
        _pointer = pointer;
        _length = length;
    }

    dynamic_array(std::initializer_list<T> elements)
    {
        _pointer = new T[elements.size()];
        int i = 0;
        for (const auto &e : elements)
        {
            _pointer[i++] = e;
        }
        _length = elements.size();
    }

    dynamic_array(const dynamic_array &other) = delete;

    dynamic_array(dynamic_array && other)
    {
        _length = other._length;
        _pointer = other._pointer;
        other._pointer = nullptr;
    }

    virtual ~dynamic_array()
    {
        if (_pointer != nullptr)
        {
            delete[] _pointer;
        }
    }

    T *pointer() const
    {
        return _pointer;
    }

    T &operator[](int index) const
    {
        return _pointer[index];
    }

    size_t length() const
    {
        return _length;
    }

    T *begin() const 
    {
        return _pointer;
    }

    T *end() const
    {
        return _pointer + _length;
    }

    void copy_from(T *other) {
        for (int i = 0; i < _length; ++i) 
        {
            _pointer[i] = other[i];    
        }
    }

protected:
    size_t _length;
    T *_pointer;
};

enum class memory_endian
{
    little,
    big
};

memory_endian system_default_endian();

memory_endian reverse_endian(memory_endian endian);

class byte_buffer : std::stringbuf
{
public:
    byte_buffer(memory_endian memory_endian = system_default_endian());

    /// @brief get basic value from byte_buffer.
    template <typename T>
    size_t get_basic(T &out)
    {
        // union typese use the same address.
        union coercion
        {
            T value;
            char data[sizeof(T)];
        };

        coercion c;
        size_t s = get_chars_with_endian(c.data, sizeof(T));
        out = c.value;

        return s;
    }

    /// @brief put basic value to byte_buffer.
    template <typename T>
    size_t put_basic(const T &in)
    {
        union coercion
        {
            T value;
            char data[sizeof(T)];
        };

        coercion c;
        c.value = in;
        return put_chars_with_endian(c.data, sizeof(T));
    }

    /// @brief get basic values from byte_buffer.
    template <typename T, size_t _C>
    size_t get_basic_array(std::array<T, _C> &arr)
    {
        union coercion
        {
            T value[_C];
            char data[sizeof(T) * _C];
        };

        coercion c;
        size_t s = get_chars_with_endian(c.data, sizeof(T), _C);

        for (int i = 0; i < _C; ++i)
        {
            arr[i] = c.value[i];
        }
        return s;
    }

    /// @brief put basic values to byte_buffer. 
    template <typename T, size_t _C>
    size_t put_basic_array(std::array<T, _C> &arr)
    {
        union coercion
        {
            T value[_C];
            char data[sizeof(T) * _C];
        };

        coercion c;
        for (int i = 0; i < _C; ++i)
        {
            c.value[i] = arr[i];
        }
        return put_chars_with_endian(c.data, sizeof(T), _C);
    }

    /// @brief get bytes from byte_buffer.
    size_t get_bytes(uint8_t *out, size_t count);

    /// @brief put bytes to byte_buffer.
    size_t put_bytes(uint8_t *out, size_t count);

    /// @brief get bytes from byte_buffer.
    size_t get_bytes(dynamic_array<char> &data);

    /// @brief put bytes to byte_buffer
    size_t put_bytes(dynamic_array<char> &data);

    /// @brief get all available bytes from byte_buffer.
    dynamic_array<char> get_bytes();

    /// @brief read_index to the head.
    size_t read_index();

    /// @brief write_position to the head. 
    size_t write_index();

    /// @brief content length in bytes. 
    size_t length();

    /// @brief available read in bytes. 
    size_t read_available();

    /// @brief seek read_bytes.
    void read_seek(size_t index);

    /// @brief skip read_bytes.
    void read_skip(size_t count);

    /// @brief seek write_bytes. fill zero if no content.
    void write_seek(size_t index);

    /// @brief skip write_bytes. fill zero i no content.
    void write_skip(size_t count);

    memory_endian get_memory_endian();

    void set_memory_endian(memory_endian endian);

private:

    size_t get_chars_with_endian(char *_ptr, size_t _count);

    size_t put_chars_with_endian(char *_ptr, size_t _count);

    size_t get_chars_with_endian(char *_ptr, size_t _element_size, size_t _count);

    size_t put_chars_with_endian(char *_ptr, size_t _element_size, size_t _count);

    /// @brief whether endian is reverse from system_default_endian.
    bool is_reverse_endian = false;
};

template <typename T, typename = std::enable_if_t<std::is_arithmetic_v<T>>>
inline byte_buffer &operator<<(byte_buffer &buffer, const T &data)
{
    buffer.put_basic(data);
    return buffer;
}

template <typename T, typename = std::enable_if_t<std::is_arithmetic_v<T>>>
inline byte_buffer &operator>>(byte_buffer &buffer, T &data)
{
    buffer.get_basic(data);
    return buffer;
}

/// @brief read array from buffer, use inherited reader.
template <typename T, size_t _C>
inline byte_buffer &operator<<(byte_buffer &buffer, const std::array<T, _C> &arr)
{
    for (int i = 0; i < arr.size(); ++i)
    {
        buffer << arr[i];
    }
    return buffer;
}

/// @brief write array to buffer, use inherited writer.
template <typename T, size_t _C>
inline byte_buffer &operator>>(byte_buffer &buffer, std::array<T, _C> &arr)
{
    for (int i = 0; i < arr.size(); ++i)
    {
        buffer >> arr[i];
    }
    return buffer;
}

inline byte_buffer &operator<<(byte_buffer &buffer, byte_buffer &other_buffer)
{
    dynamic_array<char> data_arr(other_buffer.read_available());
    other_buffer.get_bytes(data_arr);
    buffer.put_bytes(data_arr);
    return buffer;
}

int length_of_unfixed_uint32(uint32_t value);

uint32_t read_unfixed_uint32(byte_buffer &buffer);

void read_fixed_utf8_string(byte_buffer &buffer, std::string& value, size_t length);

void write_unfixed_uint32(byte_buffer &buffer, uint32_t value);

void write_fixed_utf8_string(byte_buffer &buffer, std::string value, size_t length);

std::string bytes_to_hex(dynamic_array<char> &arr);

dynamic_array<char> hex_to_bytes(const std::string &hex);

std::string byte_buffer_to_hex(byte_buffer &buffer);

uint16_t crc16_init();

uint16_t crc16_mod_bus(const dynamic_array<char> &data);

uint16_t crc16_mod_bus(byte_buffer &buffer);

void crc16_mod_bus_iter(uint16_t &crc, char *data, int length);

template <typename T>
inline void crc16_mod_bus_iter(uint16_t &crc, const T &data)
{
    union coercion
    {
        T value;
        char data[sizeof(T)];
    };

    coercion c;
    c.value = data;

    crc16_mod_bus_iter(crc, c.data, sizeof(T));
}

bool string_ends_with(const std::string &str, const std::string &suffix);

std::string fill_number_zero(int number, int width = 2);

template <typename T>
bool content_equals(std::shared_ptr<T> left, std::shared_ptr<T> right)
{
    if (left == nullptr && right == nullptr)
    {
        return true;
    }
    else if (left == nullptr || right == nullptr)
    {
        return false;
    }
    else
    {
        // use internal compare.
        return *left == *right;
    }
}

#endif