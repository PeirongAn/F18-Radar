#ifndef BIN_PROTO_DATAS_H
#define BIN_PROTO_DATAS_H

/// cpp head files storage for bin_protos
#include <string>
#include <vector>
#include <memory>
#include <map>
#include "bin_proto_basics.h"


enum class biovital_data_type
{
    /// @brief 六轴
    imu,
    /// @brief 肌电
    emg,
    /// @brief 心电
    ecg,
    /// @brief 皮肤电
    eda,
    /// @brief PPG-HR
    ppg_green,
    /// @brief PPG-SPO
    ppg_red_ir,
    /// @brief 体温
    skin_temp,
    /// @brief 分析结果
    alg,
    /// @brief 环境大气压
    epa,
    /// @brief 环境温湿度
    eht,
    /// @brief 设备温度
    device_temp,
    /// @brief 光强
    light,
    /// @brief 地磁强度
    magn,
    /// @brief 心率变异性
    hrv,
    /// @brief 心率算法数据
    hr_alg,
    /// @brief 血氧算法数据
    spo_alg,
    /// @brief 体温数据
    body_temp,
};

std::string to_string(biovital_data_type data_type);

enum class bin_op_code : uint16_t
{
    /// @brief 查询设备固件版本号
    query_firmware_version = 0x0000,

    /// @brief 查询“科研模式下” 传感器 参数信息
    query_sci_sensor_info = 0x0004,

    /// @brief 查询腕表系统时间
    query_device_time = 0x0006,

    /// @brief 查询“科研”模式下腕表采集模式
    query_sci_capture_mode = 0x0007,

    /// @brief 查询腕表工作状态（信息）
    query_device_info = 0x0009,

    /// @brief 查询ecg通道
    query_ecg_channel = 0x000c,

    /// @brief 设置采集模式
    set_sci_capture_mode = 0x0101,

    /// @brief 设备腕表系统时间
    set_device_time = 0x0102,

    /// @brief 设备传感器采集参数
    set_sci_sensor_info = 0x0106,

    /// @brief 设置ecg通道
    set_ecg_channel = 0x010c,

    /// @brief 应用下发消息
    dispatch_app_message = 0x0112,

    report_epa = 0x0200,

    report_eht = 0x0201,

    report_temp_internal = 0x0202,

    report_temp_skin = 0x0203,

    report_imu = 0x0204,

    report_light = 0x0205,

    report_magnetism = 0x0206,

    report_eda = 0x0207,

    report_ppg_hr = 0x020A,

    /// @brief 腕表主动上报PPG SPO2 RAW数据
    report_ppg_spo = 0x020B,

    /// @brief 腕表主动上报PPG_ECG_RAW数据
    report_ppg_ecg = 0x020E,

    /// @brief 腕表主动上报算法结果
    report_alg_result = 0x0300,

    /// @brief 腕表主动上报HRV结果
    report_hrv_result = 0x0301,
};

std::string to_string(bin_op_code op_code);

bool is_report_data_response(bin_op_code op_code);

biovital_data_type to_data_type(bin_op_code op_code);

class bin_data
{
public:
    virtual bin_op_code get_op_code() = 0;
};

class bin_pack
{
public:
    bin_pack(size_t seq_number, dynamic_array<char> data) 
        : seq_number(seq_number), data(std::move(data))
    {
        if (seq_number <= 0)
        {
            throw std::exception("seq_number should be zero.");
        }
    }

    bin_pack(size_t seq_number, size_t package_length, uint8_t flag, dynamic_array<char> data)
        : seq_number(seq_number), package_length(package_length), flag(flag), data(std::move(data))
    {
        if (seq_number > 0)
        {
            throw std::exception("seq_number should be zero.");
        }
    }    
    
    size_t seq_number;
    size_t package_length;
    uint8_t flag;
    dynamic_array<char> data;
};

class biovital_data_point
{
public:
    biovital_data_point(biovital_data_type data_type, uint64_t time_milliseconds, std::vector<double> datas);

    biovital_data_type data_type;
    uint64_t time_milliseconds;
    std::vector<double> datas;

    /// @brief cast the biovital_data_point to text_scale
    /// @return 
    std::shared_ptr<biovital_data_point> to_text_scale();

};


class biovital_data_point_reader
{
public:
    size_t size_in_bytes_for(biovital_data_type data_type);


    std::shared_ptr<biovital_data_point> read_from_buffer(biovital_data_type data_type, byte_buffer &buffer, bool flag);
};

enum volume_kind
{
    b,
    kb,
    mb,
    gb,
    tb
};

class disk_volume
{
public:

    static volume_kind from_ordinal(int ordinal);

    disk_volume(long in_bytes);


    std::pair<double, volume_kind> formated();

    long in_bytes;
};

enum class flash_kind
{
    no_flash = 0,
    sd = 1,
    emmc = 2
};

enum class sci_capture_mode
{
    ble = 1,
    wifi = 2,
    offline = 0
};

class sensor_config
{
public:

    sensor_config(uint16_t rate, int enabled);

    std::shared_ptr<sensor_config> copy_enabled(bool enabled);

    uint16_t rate;
    bool enabled;
};

class sensor_config_enhanced
{
public:
    sensor_config_enhanced(uint16_t raw_rate, uint16_t alg_rate, bool enabled);

    std::shared_ptr<sensor_config_enhanced> copy_enabled(bool enabled);

    uint16_t raw_rate;
    uint16_t alg_rate;
    bool enabled;
};

class version
{
public:
    version(uint8_t major, uint8_t minor, uint8_t revision);

    uint8_t major;
    uint8_t minor;
    uint8_t revision;
};

enum class wear_status
{
    idle,
    wearing
};

enum class t1_channel
{
    inner = 0,
    outer = 1
};

template <int Size>
class convs
{
private:
    double cube_values[Size];
    double ks[Size];
    int current_index = 0;
    bool init = false;

public:
    convs(std::initializer_list<double> ks)
    {
        int i = 0;
        for (double item : ks)
        {
            this->ks[i++] = item;
        }
    }

    double transfrom(double input)
    {
        if (!init) {
            for (int i = 0; i < Size; ++i) {
                cube_values[i] = input;
            }
            init = true;
        }

        cube_values[current_index] = input;
        current_index++;
        if (current_index >= Size)
        {
            current_index = 0;
        }

        double result = 0;
        for (int i = 0; i < Size; ++i) {
            int element_index = (current_index + i) % Size;
            result += cube_values[element_index] * ks[i];
        }
        return result;
    }
};

struct hrv_data_cell {
    uint64_t time_milliseconds;
    std::vector<double> rris;

    hrv_data_cell(uint64_t time_milliseconds, std::vector<double> rris): time_milliseconds(time_milliseconds), rris(rris) 
    {

    }
};

class hrv_data_accumulator {
private:
    uint64_t sync_time_millis = 0;
    uint64_t record_time_millis = 0;
    uint64_t refresh_time = 3600000;
    double previous_rri = -1;
    convs<3> convs = {0.1, 0.3, 0.6};


public:
    std::vector<std::shared_ptr<biovital_data_point>> push_hrv_data(std::shared_ptr<biovital_data_point> data_chip);

private:

    static std::shared_ptr<hrv_data_cell> cast_data(std::shared_ptr<biovital_data_point> data_chip);
};

/// @brief to transfrom the adc data to real data.
class biovital_data_transformer {
public:
    biovital_data_transformer(bool open_fill_data): open_fill_data(open_fill_data) {

    }

    std::vector<std::shared_ptr<biovital_data_point>> cast(biovital_data_type data_type, std::vector<std::shared_ptr<biovital_data_point>> &data_points);

private:
    std::map<biovital_data_type, std::shared_ptr<biovital_data_point>> last_data_point;
    std::shared_ptr<hrv_data_accumulator> accumulator = std::make_shared<hrv_data_accumulator>();
    bool open_fill_data;

    std::vector<std::shared_ptr<biovital_data_point>> filling(biovital_data_type data_type, std::vector<std::shared_ptr<biovital_data_point>> &data_points);

    static std::shared_ptr<biovital_data_point> to_real_scale(std::shared_ptr<biovital_data_point> that);
    std::vector<std::shared_ptr<biovital_data_point>> hrv_cast(std::shared_ptr<biovital_data_point> that);
};

#endif