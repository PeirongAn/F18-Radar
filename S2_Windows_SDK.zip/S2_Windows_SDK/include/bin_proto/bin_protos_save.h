#ifndef BINPROTOSSAVE_H
#define BINPROTOSSAVE_H

#include <map>
#include <string>
#include <memory>
#include "bin_protos.h"

class text_writer;

/// @brief 保存时路径的解析方式
enum path_resolve_kind
{
    /// @brief default, $path/imu_raw/20250307/15的默认按时间划分的格式
    auto_times,

    /// @brief $path/imu_raw的自定义解析方式
    single,
};


class save_file_system
{
public:
    virtual std::string seperator() = 0;

    /// @brief 解析基础的文件夹路径
    /// @param device_mac_address 设备的mac地址，大写十六进制，冒号分隔。
    /// @param time_millis 毫秒级时间戳，按epoch经过的时间计算
    /// @return 
    virtual std::string get_base_dir(const std::string &device_mac_address, const uint64_t time_millis) = 0;

    virtual std::shared_ptr<text_writer> create_writer(const std::string &file_path, bool append = false) = 0;

    /// @brief 文件保存的间隔时间，停止采集时，无论多长时间，立即全部保存
    virtual int time_seconds_between();

    /// @brief 开启数据填充
    virtual bool open_fill_data();

    /// @brief 路径解析的方式
    virtual path_resolve_kind resolve_kind();

    std::string resolve_directory_path(const std::string &parent, std::vector<std::string> paths);

    std::string resolve_file_path(const std::string &parent, std::vector<std::string> paths);

    std::string fill_directory_path(const std::string &path);

    std::string parent_directory(const std::string &path);
};

class text_writer
{
public:
    virtual bool write_text(const std::string &text) = 0;

    virtual bool close() = 0;
};

std::string record_filename_tag_t1(biovital_data_type data_type);

void milliseconds_to_datetime(uint64_t time_millis, int &year, int &month, int &day, int &hour, int &minute, int &second);

class date_hour_token {
public:
    int year;
    int month;
    int day;
    int hour;

    static date_hour_token from_milliseconds(uint64_t time_millis);

    bool operator == (const date_hour_token &other) const {
        return year == other.year && month == other.month && day == other.day && hour == other.hour;
    }

    bool operator != (const date_hour_token &other) const {
        return !(*this == other);
    }

    std::string date_name();

    std::string hour_name();

private:


};

class alg_part_model
{
public:
    void push_alg_data_points(std::vector<std::shared_ptr<biovital_data_point>> data_points);

    std::vector<std::shared_ptr<biovital_data_point>> hr_part;
    std::vector<std::shared_ptr<biovital_data_point>> spo_part;
    std::vector<std::shared_ptr<biovital_data_point>> body_temp_part;
};

class bin_save_transaction
{
public:
    bin_save_transaction(uint64_t start_time_millis, std::string device_mac_address, std::shared_ptr<save_file_system> file_system);

    void stop_transaction();

    void push_data(std::shared_ptr<common_data_response> resp);

    uint64_t start_time_seconds;
    uint64_t stop_time_seconds;

private:
    void save_data();

    void save_data_with_data_type(biovital_data_type data_type, std::vector<std::shared_ptr<biovital_data_point>> data_points);

    std::string write_chip(std::shared_ptr<biovital_data_point> data_point);

    void write_chip_value(std::shared_ptr<text_writer> writer, std::shared_ptr<biovital_data_point> data_point);

    void save_data_with_data_type_auto_times(biovital_data_type data_type, std::vector<std::shared_ptr<biovital_data_point>> data_points);

    void save_data_with_data_type_single(biovital_data_type data_type, std::vector<std::shared_ptr<biovital_data_point>> data_points);

    uint64_t last_save_time_seconds;
    std::map<biovital_data_type, std::vector<std::shared_ptr<common_data_response>>> received_cache;
    /// @brief 最后保存的数据。
    std::map<biovital_data_type, std::shared_ptr<biovital_data_point>> last_data_point;
    std::string device_mac_address;
    std::shared_ptr<save_file_system> file_system;

    std::string base_dir;
};

#endif