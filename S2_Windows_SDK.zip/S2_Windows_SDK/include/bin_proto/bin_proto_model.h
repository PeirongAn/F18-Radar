/// @author real-wecare
/// 专用于处理波形数据的数据集

#ifndef BINPROTOMODEL_H
#define BINPROTOMODEL_H

#include <vector>
#include <string>
#include <memory>
#include <map>
#include <functional>
#include <iostream>

#include "bin_protos.h"

// type definitions.
class graphic_page;

enum class sensor_type
{
    acceleration,
    gyroscope,
    emg,
    eda,
    ppg_green,
    ppg_red_ir,
    skin_temp,
    epa,
    eh,
    et,
    device_temp,
    light,
    magn,
    hr_alg,
    spo_alg,
    body_temp,
    rr,
    hrv
};

std::string sensor_type_code(sensor_type sensor_type);

int sensor_type_dimension(sensor_type sensor_type);

enum class sensor_color
{
    normal,
    red,
    orange,
    yellow,
    green,
    cyan,
    blue,
    purple
};

std::vector<sensor_color> sensor_color_values();

sensor_color with_overflow_index(int index);

class sensor_dimension
{
public:
    sensor_dimension(std::string dimension_label, sensor_color color);

    std::string dimension_label;
    sensor_color color;
};

class sensor_label
{
public:
    sensor_label(sensor_type type, std::string unit_label, std::vector<std::shared_ptr<sensor_dimension>> dimensions);

    sensor_type type;
    std::string unit_label;
    std::vector<std::shared_ptr<sensor_dimension>> dimensions;
};

class point_2d
{
public:
    point_2d(double x, double y);

    double x;
    double y;
};

class graph_comp_creator
{
public:
    double data_cache_seconds = 20.0;

    std::shared_ptr<sensor_label> create_label(sensor_type type, int repeats);

    std::shared_ptr<graphic_page> create_page(sensor_type type);

private:
    std::string suffix_of(int index, int repeats)
    {
        if (repeats == 1)
        {
            return "";
        }
        else
        {
            return std::to_string(index + 1);
        }
    }

    std::shared_ptr<sensor_label> acceleration(int repeats);

    std::shared_ptr<sensor_label> gyroscope(int repeats);

    std::shared_ptr<sensor_label> emg(int repeats);

    std::shared_ptr<sensor_label> eda(int repeats);

    std::shared_ptr<sensor_label> ppg_green(int repeats);

    std::shared_ptr<sensor_label> ppg_red_ir(int repeats);

    std::shared_ptr<sensor_label> skin_temp(int repeats);

    std::shared_ptr<sensor_label> epa(int repeats);

    std::shared_ptr<sensor_label> eh(int repeats);

    std::shared_ptr<sensor_label> et(int repeats);

    std::shared_ptr<sensor_label> device_temp(int repeats);

    std::shared_ptr<sensor_label> light(int repeats);

    std::shared_ptr<sensor_label> magn(int repeats);

    std::shared_ptr<sensor_label> hr_alg(int repeats);

    std::shared_ptr<sensor_label> spo_alg(int repeats);

    std::shared_ptr<sensor_label> rr(int repeats);

    std::shared_ptr<sensor_label> hrv(int repeats);

    std::shared_ptr<sensor_label> body_temp(int repeats);
};

class data_summary
{
public:
    double total_avg;
    std::map<int, double> channel_avg;

    data_summary(double total_avg, std::map<int, double> channel_avg);

    static std::shared_ptr<data_summary> from_datas(const std::map<int, std::vector<point_2d>> &datas, double time_last);

private:
    static std::map<int, std::vector<double>> transform(const std::map<int, std::vector<point_2d>> &datas, double time_last);

    static int binary_search_points(const std::vector<point_2d> &list, double target);

    static double sqrt_list(const std::vector<double> &data);
};

class graphic_page
{
public:
    graphic_page(sensor_type type, graph_comp_creator *comp_creator, double cached_time_seconds);

    std::shared_ptr<sensor_label> label;
    graph_comp_creator *comp_creator;
    double cached_time_seconds = 0.0;

    double start_offset = 0.0;
    double x_axis_min = 0.0;
    double x_axis_max = 0.0;

    std::map<int, std::vector<point_2d>> datas;
    std::shared_ptr<data_summary> summary = nullptr;

    std::function<void()> data_changed = nullptr;
    std::function<void(std::shared_ptr<sensor_label>)> label_changed = nullptr;
    std::function<void(int, std::vector<point_2d> &)> data_pushed = nullptr;

    void create_label(int repeats);

    void push_data(int index, std::vector<point_2d> &points);

    void notify_data_changed();

    void remove_cache_elderly(double next_time);

private:
};

class graphic_model
{
public:
    std::shared_ptr<graphic_page> page_of(sensor_type type);

    void create_label(sensor_type type, int repeats);

    void push_data(sensor_type type, int index, std::vector<point_2d> &points);

    void notify_data_push_finished(sensor_type type);

    std::map<sensor_type, std::shared_ptr<graphic_page>> pages;
    std::shared_ptr<graph_comp_creator> creator = std::make_shared<graph_comp_creator>();
    std::function<void()> data_changed;
};

class graphic_model_adapter
{
public:
    graphic_model_adapter(std::shared_ptr<graphic_model> model);

    void push_data(biovital_data_type data_type, std::vector<std::shared_ptr<biovital_data_point>> data_points);

    void push_data_imu(std::vector<std::shared_ptr<biovital_data_point>> data_points);

    void push_data_ecg(std::vector<std::shared_ptr<biovital_data_point>> data_points);

    void push_data_ppg(std::vector<std::shared_ptr<biovital_data_point>> data_points);

    void push_data_spo(std::vector<std::shared_ptr<biovital_data_point>> data_points);

    void push_data_eda(std::vector<std::shared_ptr<biovital_data_point>> data_points);

    void push_data_skin_temp(std::vector<std::shared_ptr<biovital_data_point>> data_points);

    void push_data_epa(std::vector<std::shared_ptr<biovital_data_point>> data_points);

    void push_data_eht(std::vector<std::shared_ptr<biovital_data_point>> data_points);

    void push_data_device_temp(std::vector<std::shared_ptr<biovital_data_point>> data_points);

    void push_data_light(std::vector<std::shared_ptr<biovital_data_point>> data_points);

    void push_data_magn(std::vector<std::shared_ptr<biovital_data_point>> data_points);

    void push_data_alg(std::vector<std::shared_ptr<biovital_data_point>> data_points);

    void push_data_hrv(std::vector<std::shared_ptr<biovital_data_point>> data_points);

    std::shared_ptr<graphic_model> model;

private:

    std::shared_ptr<hrv_data_accumulator> accumulator = std::make_shared<hrv_data_accumulator>();

    void create_dimensions(std::vector<std::shared_ptr<biovital_data_point>> &data_points, int dimension_length, sensor_type type);

    void map_from_to(std::vector<std::shared_ptr<biovital_data_point>> &data_points, int from_index, int to_index, int dimension_length, sensor_type type);

    void push_data_to_vector(std::vector<point_2d> &collection, sensor_type type, std::shared_ptr<biovital_data_point> data_point, int from_index);
};

#endif