/// it is a file contains a

#ifndef BINPROTOS_H
#define BINPROTOS_H

#include <vector>
#include <memory>
#include <string>
#include "bin_proto_datas.h"

#define DEVICE_SET_TIME_MILLIS_OPTION

class common_data_response: public bin_data
{
public:
    common_data_response(bin_op_code op_code, biovital_data_type data_type, std::vector<std::shared_ptr<biovital_data_point>> data_points);

    virtual bin_op_code get_op_code() override;

    bin_op_code op_code;
    biovital_data_type data_type;
    std::vector<std::shared_ptr<biovital_data_point>> data_points;
};

void print_common_data_response(std::shared_ptr<common_data_response> resp);

void print_data_point(std::shared_ptr<biovital_data_point> point);

class query_firmware_version_request: public bin_data
{
public:
    virtual bin_op_code get_op_code() override;
};

class query_firmware_version_response: public bin_data
{
public:
    query_firmware_version_response(std::shared_ptr<version> base_version, std::shared_ptr<version> wifi_version, std::shared_ptr<version> cluster_version, std::string ble_name);

    virtual bin_op_code get_op_code() override;
    std::shared_ptr<version> base_version;
    std::shared_ptr<version> wifi_version;
    std::shared_ptr<version> cluster_version;
    std::string ble_name;
};

class query_sci_sensor_info_request: public bin_data
{
public:
    virtual bin_op_code get_op_code() override;
};

class query_sci_sensor_info_response: public bin_data
{
public:
    query_sci_sensor_info_response(
        std::shared_ptr<sensor_config> imu,
        std::shared_ptr<sensor_config> geo_magn,
        std::shared_ptr<sensor_config_enhanced> emg,
        std::shared_ptr<sensor_config_enhanced> ppg_green,
        std::shared_ptr<sensor_config_enhanced> ppg_red_ir,
        std::shared_ptr<sensor_config> eda,
        std::shared_ptr<sensor_config> eht,
        std::shared_ptr<sensor_config> temp,
        std::shared_ptr<sensor_config> skin_temp,
        std::shared_ptr<sensor_config> epa,
        std::shared_ptr<sensor_config> el
    );

    virtual bin_op_code get_op_code() override;
    std::shared_ptr<sensor_config> imu;
    std::shared_ptr<sensor_config> geo_magn;
    std::shared_ptr<sensor_config_enhanced> emg;
    std::shared_ptr<sensor_config_enhanced> ppg_green;
    std::shared_ptr<sensor_config_enhanced> ppg_red_ir;
    std::shared_ptr<sensor_config> eda;
    std::shared_ptr<sensor_config> eht;
    std::shared_ptr<sensor_config> temp;
    std::shared_ptr<sensor_config> skin_temp;
    std::shared_ptr<sensor_config> epa;
    std::shared_ptr<sensor_config> el;
};

class query_device_time_request: public bin_data
{
public:
    virtual bin_op_code get_op_code() override;
};

class query_device_time_response: public bin_data
{
public:
    query_device_time_response(uint8_t time_zone, uint32_t time_seconds);
    virtual bin_op_code get_op_code() override;
    uint8_t time_zone;
    uint32_t time_seconds;
};

class query_sci_capture_mode_request: public bin_data
{
public:
    virtual bin_op_code get_op_code() override;
};

class query_sci_capture_mode_response: public bin_data
{
public:
    query_sci_capture_mode_response(sci_capture_mode capture_mode);
    virtual bin_op_code get_op_code() override;
    sci_capture_mode capture_mode;
};

class query_device_info_request: public bin_data
{
public:
    virtual bin_op_code get_op_code() override;
};

class query_device_info_response: public bin_data
{
public:
    query_device_info_response(
        uint16_t battery_volume,
        uint16_t standard_battery_voltage,
        uint16_t current_battery_voltage,
        uint8_t battery_percent,
        uint32_t max_sd_volume,
        uint32_t remain_sd_volume,
        flash_kind flash_kind,
        wear_status wear_status
    );

    virtual bin_op_code get_op_code() override;
    uint16_t battery_volume;
    uint16_t standard_battery_voltage;
    uint16_t current_battery_voltage;
    uint8_t battery_percent;
    uint32_t max_sd_volume;
    uint32_t remain_sd_volume;
    flash_kind _flash_kind;
    wear_status _wear_status;

};

class query_ecg_channel_request: public bin_data
{
public:
    virtual bin_op_code get_op_code() override;
};

class query_ecg_channel_response: public bin_data
{
public:
    query_ecg_channel_response(t1_channel channel);

    virtual bin_op_code get_op_code() override;
    t1_channel channel;
};

class set_device_time_request: public bin_data
{
public:
#ifndef DEVICE_SET_TIME_MILLIS_OPTION
    set_device_time_request(uint8_t offset_in_hours, uint32_t time_seconds);
#else
    set_device_time_request(uint8_t offset_in_hours, uint32_t time_seconds, uint8_t adjustment_sign, uint16_t adjustment_millis);
#endif

    virtual bin_op_code get_op_code() override;
    uint8_t offset_in_hours;
    uint32_t time_seconds;

#ifdef DEVICE_SET_TIME_MILLIS_OPTION
    uint8_t adjustment_sign;
    uint16_t adjustment_millis;
#endif

};

class set_device_time_response: public bin_data
{
public:
    set_device_time_response(bool success);

    virtual bin_op_code get_op_code() override;
    bool success;
};

class set_sci_sensor_info_request: public bin_data
{
public:
    set_sci_sensor_info_request(
        std::shared_ptr<sensor_config> imu,
        std::shared_ptr<sensor_config> geo_magn,
        std::shared_ptr<sensor_config_enhanced> emg,
        std::shared_ptr<sensor_config_enhanced> ppg_green,
        std::shared_ptr<sensor_config_enhanced> ppg_red_ir,
        std::shared_ptr<sensor_config> eda,
        std::shared_ptr<sensor_config> eht,
        std::shared_ptr<sensor_config> temp,
        std::shared_ptr<sensor_config> skin_temp,
        std::shared_ptr<sensor_config> epa,
        std::shared_ptr<sensor_config> el
    );

    virtual bin_op_code get_op_code() override;

    std::shared_ptr<sensor_config> imu;
    std::shared_ptr<sensor_config> geo_magn;
    std::shared_ptr<sensor_config_enhanced> emg;
    std::shared_ptr<sensor_config_enhanced> ppg_green;
    std::shared_ptr<sensor_config_enhanced> ppg_red_ir;
    std::shared_ptr<sensor_config> eda;
    std::shared_ptr<sensor_config> eht;
    std::shared_ptr<sensor_config> temp;
    std::shared_ptr<sensor_config> skin_temp;
    std::shared_ptr<sensor_config> epa;
    std::shared_ptr<sensor_config> el;
};

class set_sci_sensor_info_response: public bin_data
{
public:
    set_sci_sensor_info_response(bool success);

    virtual bin_op_code get_op_code() override;

    bool success;
};

class set_ecg_channel_request: public bin_data
{
public:
    set_ecg_channel_request(t1_channel channel);

    virtual bin_op_code get_op_code() override;
    t1_channel channel;
};

class set_ecg_channel_response: public bin_data
{
public:
    set_ecg_channel_response(bool success);

    virtual bin_op_code get_op_code() override;
    bool success;
};

class set_sci_capture_mode_request: public bin_data
{
public:
    set_sci_capture_mode_request(sci_capture_mode capture_mode, bool is_open);

    virtual bin_op_code get_op_code() override;

    sci_capture_mode capture_mode;
    bool is_open;
};

class set_sci_capture_mode_response: public bin_data
{
public:
    set_sci_capture_mode_response(bool success);

    virtual bin_op_code get_op_code() override;

    bool success;
};

class dispatch_app_message_request: public bin_data
{
public:
    dispatch_app_message_request(
        std::string title,
        std::string content
    );

    virtual bin_op_code get_op_code() override;

    std::string title;
    std::string content;
};

class dispatch_app_message_response: public bin_data
{
public:
    dispatch_app_message_response(bool success);

    virtual bin_op_code get_op_code() override;

    bool success;
};

#endif