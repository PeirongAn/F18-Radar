#ifndef BINPROTOSIO_H
#define BINPROTOSIO_H

#include "bin_proto_basics.h"
#include "bin_proto_datas.h"

#include <vector>
#include <memory>

class biovital_bin_data_io
{
public:
    biovital_bin_data_io(byte_buffer buffer);

    std::shared_ptr<bin_pack> read_bin_pack();

    std::shared_ptr<bin_data> read_bin_data();

    void write_bin_data(std::shared_ptr<bin_data> bin_data);
    
    void write_bin_pack(std::shared_ptr<bin_pack> bin_pack);

    std::shared_ptr<bin_data> read_bin_data_content(bin_op_code op_code);

    void write_bin_data_content(std::shared_ptr<bin_data> bin_data);

    byte_buffer buffer;
};

class bin_pack_processor_callback
{
public:
    virtual void send_failure(std::string msg) {}

    virtual void received_failure(std::string msg) {}

    virtual void received(std::shared_ptr<bin_data> data) {}
};

class bin_pack_processor
{
public:
    int mtu = 0;
    std::shared_ptr<bin_pack_processor_callback> callback = nullptr;

    void add_package(dynamic_array<char> data);

    std::vector<dynamic_array<char>> build_send_packages(std::shared_ptr<bin_data> bin_data);

private:
    std::shared_ptr<biovital_bin_data_io> io_from(byte_buffer buffer);

    void reset();
    
    void collect_and_send();
    
    /// @brief 当前序列id
    long seq_number = 0;
    std::vector<std::shared_ptr<bin_pack>> packs;
    long total_length = 0;
    long received_length = 0;
};

#endif