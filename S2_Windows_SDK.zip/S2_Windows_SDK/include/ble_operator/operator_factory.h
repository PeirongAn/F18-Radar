#pragma once
#include <string>
#include <memory>
//#include "gatt_opetaror_interface.h"

#ifdef BLEOPERATOR_EXPORTS
#define OPERATOR_DLL __declspec(dllexport)
#else
#define OPERATOR_DLL __declspec(dllimport)
#endif

#pragma warning(push)
#pragma warning(disable: 4251) // std::string in exported class (same CRT, safe)

namespace ble_operator {

	enum class LicenseResult {
		kSuccess = 0,       // Authorization valid
		kInvalidFormat,     // License key decryption/parsing failed
		kExpired,           // Authorization expired
		kNotSet,            // SetLicense not called
	};

	class IBleScanner;
	class IGattOperator;
	class IGattCallBack;
	class IBleScannerCallBack;
	class OPERATOR_DLL OperatorFactory
	{
		OperatorFactory() = default;
	public:
		~OperatorFactory() = default;

		static OperatorFactory* GetInstance();

		// must be called before any other operation
		LicenseResult SetLicense(const std::string& license_key);

		// must be called after SetLicense
		void InitLog(const std::string& log_file_path,
			bool disable_logs = false,
			uint64_t logging_level = 1,
			uint64_t log_file_cnt = 1,
			uint64_t log_file_size = 1048576 * 5);


		std::shared_ptr<IBleScanner> CreateBleScanner(IBleScannerCallBack* callback);
		std::shared_ptr<IGattOperator> CreateBleGattClient(uint64_t ble_addr, IGattCallBack* callback);
	private:
		bool license_valid_ = false;
		std::string license_machine_code_;
		std::string license_end_time_;
	};

#pragma warning(pop)
}
