#pragma once
#include <string>
#include <functional>
#include <list>

namespace ble_operator {


}