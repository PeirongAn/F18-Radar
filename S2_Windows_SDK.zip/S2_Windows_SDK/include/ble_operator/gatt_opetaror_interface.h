#pragma once
#include <string>
namespace ble_operator {
    
    enum class GattOperateType {
        kInitBleDevice = 0,
        kEnumGattService,
        kRegRecvCmdNotify,
        kRegDataTransNotify,
        //kSendCmd
    };

    class IGattCallBack {
    public:
        virtual ~IGattCallBack() = default;

        virtual void OnOperateResult(const GattOperateType type, const bool success) = 0;

        virtual void OnError() = 0;

        virtual void OnCmdSendResult(const bool success) = 0;
        virtual void OnCmdRecv(const uint8_t* data, int length) = 0;
        virtual void OnDataRecv(const uint8_t* data, int length) = 0;
    };

    class IGattOperator {
    public:
        virtual ~IGattOperator() = default;

        virtual bool InitBleDevice() = 0;
        virtual bool EnumGattServices() = 0;
        virtual bool RegGattServicesNotify() = 0;
        virtual bool SendCmd(const char* data, const int length) = 0;
        virtual bool Close() = 0;
    };

}