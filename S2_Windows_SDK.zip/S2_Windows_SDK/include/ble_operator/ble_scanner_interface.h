#pragma once
#include <memory>
#include <string>
#include <functional>
#include <list>

namespace ble_operator {
    struct BleDeviceInfo {
        char name[256] = { 0 };
        char type[256] = { 0 };
        char ble_id[256] = { 0 };
        unsigned long long ble_addr = 0;
    };

    enum class ScannerState {
        kNone,
        kStarted,
        kComplete,
        kStopped
    };

    class IBleScannerCallBack {
    public:
        virtual ~IBleScannerCallBack() = default;

        virtual void OnBleAdd(BleDeviceInfo info) = 0;
        virtual void OnBleUpdate(unsigned long long ble_addr, BleDeviceInfo info) = 0;
        virtual void OnBleRemove(unsigned long long ble_addr) = 0;

        virtual void OnScannerStateChanged(ScannerState state) = 0;
    };

    class IBleScanner {
    public:
        virtual void Init() = 0;
        virtual void StartScan(char* ble_name_filtter, int size) = 0;
        virtual void StopScan() = 0;

        virtual void Reset() = 0;
    };
}