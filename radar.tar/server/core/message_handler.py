import json
import time
import random
import asyncio
from typing import Dict, Any, List, Tuple, Optional, Union

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from managers import config_manager, db_manager, TaskScenarioManager, generate_task_id, target_manager, threat_manager

class MessageHandler:
    """消息处理器，负责处理客户端消息和业务逻辑"""
    
    def __init__(self):
        self.current_session = {
            'task_id': None,
            'stage': 'init',
            'target_elevation': None,
            'operations': []
        }
    
    async def handle_client_message(self, message_str: str, session_state: Dict[str, Any], 
                                  websocket=None) -> Union[List[Dict[str, Any]], Tuple[Dict[str, Any], bool], bool]:
        """处理客户端消息"""
        try:
            print("\n===== 接收到客户端消息 =====")
            print(f"原始消息: {message_str}")
            
            message = json.loads(message_str)
            print(f"解析后的消息: {message}")
            
            message_type = message.get('type', '')
            client_event_owner = message.get('event_owner', '')

            # 路由到具体的处理方法
            if message_type == 'task_start':
                return await self._handle_task_start(message, session_state)
            elif message_type == 'settings_update':
                return await self._handle_settings_update(message, session_state, client_event_owner)
            elif message_type == 'antenna_adjusted':
                return await self._handle_antenna_adjusted(message, session_state, client_event_owner)
            elif message_type == 'target_selected':
                return await self._handle_target_selected(message, session_state, client_event_owner)
            elif message_type == 'threat_clicked':
                return await self._handle_threat_clicked(message, session_state, client_event_owner)
            elif message_type == 'record_operation':
                return await self._handle_record_operation(message, session_state, client_event_owner)
            elif message_type == 'record_bulk_operations':
                return await self._handle_record_bulk_operations(message, session_state, client_event_owner)
            elif message_type in ['SwitchSA', 'ResetSA']:
                return await self._handle_sa_operations(message, session_state, websocket)
            # elif message_type == 'reset_targets':
            #     return await self._handle_reset_targets(message, session_state)
            else:
                print(f"未知消息类型: {message_type}")
                return []
                
        except json.JSONDecodeError as e:
            print(f"解析JSON时出错: {e}")
        except Exception as e:
            print(f"处理客户端消息时出错: {e}")
        
        print("===== 客户端消息处理失败 =====\n")
        return []
    
    async def _handle_task_start(self, message: Dict[str, Any], session_state: Dict[str, Any]) -> List[Dict[str, Any]]:
        """处理任务开始消息"""
        print("消息类型: task_start", message.get('user_id', ''))
        is_ai_active_request = message.get('include_ai', False)
        user_id = message.get('user_id', '')
        event_owner = 'AI' if is_ai_active_request else 'manual'
        is_practice = message.get('is_practice', False)
        session_state['is_practice'] = is_practice

        if not user_id:
            return [{"type": "error", "message": "user_id is required for task_start"}]
        
        # 将 user_id 保存到全局会话，以便后续操作使用
        self.current_session['user_id'] = user_id
        
        task_type = 'RADAR_TARGETING'
        
        # 创建或加载与用户绑定的持久化任务管理器
        task_manager = TaskScenarioManager(config_manager.get_config(), user_id, task_type, is_practice=is_practice, is_ai_active_request=is_ai_active_request)
        session_state['task_manager'] = task_manager
        
        # 从管理器获取下一个任务场景
        current_scenario = task_manager.get_next_task_parameters(is_ai_active_request)
        
        if current_scenario == "ALL_COMPLETED":
            return [{"type": "all_tasks_completed", "task_type": task_type, "message": "祝贺！所有雷达目标识别任务已完成。"}]
        if not current_scenario:
            return [{"type": "all_tasks_completed", "task_type": task_type, "message": f"当前模式的{task_type}任务已完成。"}]

        self.current_session[f'{task_type}_scenario'] = current_scenario
        task_id = generate_task_id()
        self.current_session['task_id'] = task_id
        
        # 记录操作
        if not session_state.get('is_practice', False):
            operation = {
                'task_id': task_id,
                'operationType': 'task_start',
                'timestamp': message.get('timestamp', int(time.time() * 1000)),
                'isActive': True,
                'parameters': {'include_ai': is_ai_active_request},
                'user_id': user_id,
                'event_owner': event_owner
            }
            db_manager.record_operation(operation, session_state.get('is_practice', False))
        else:
            print("练习模式，跳过 task_start 数据库记录。")

        db_manager.record_task_settings(task_id, current_scenario, user_id, event_owner, session_state.get('is_practice', False))
        target_manager.initialize_targets(current_scenario['difficulty_config'])

        init_response = {
            "type": "init_settings",
            "task_id": task_id,
            "timestamp": time.time() * 1000,
            "settings": {"range": 80, "scanAngle": 30},
            "is_ai_active": current_scenario['is_ai_active'],
            "ai_level": current_scenario.get('ai_level_name'),
            "ai_configs": config_manager.get_ai_levels(),
            "audio_enabled": current_scenario['audio_enabled'],
            "repetition_info": current_scenario['repetition_info'],
            "task_type": task_type
        }
        return [init_response]
    
    async def _handle_settings_update(self, message: Dict[str, Any], session_state: Dict[str, Any], 
                                    client_event_owner: str) -> List[Dict[str, Any]]:
        """处理设置更新消息"""
        print("消息类型: settings_update")
        
        # 验证雷达参数是否与init_settings一致
        client_range = message.get('range')
        client_scan_angle = message.get('scanAngle')
        required_range = 80
        required_scan_angle = 30

        if client_range == required_range and client_scan_angle == required_scan_angle:
            # 参数正确，进入天线调整阶段
            print("雷达参数验证成功，发送天线调整指令。")
            
            if not session_state.get('is_practice', False):
                operation = {
                    'task_id': self.current_session.get('task_id'),
                    'operationType': 'settings_update',
                    'timestamp': message.get('timestamp', int(time.time() * 1000)),
                    'receive_timestamp': message.get('receive_timestamp'),
                    'isActive': True,
                    'parameters': message,
                    'user_id': message.get('user_id', ''),
                    'event_owner': client_event_owner
                }
                db_manager.record_operation(operation, session_state.get('is_practice', False))
            else:
                print("练习模式，跳过 settings_update 数据库记录。")

            validation_response = {"type": "settings_validation", "status": "success", "message": "雷达参数设置正确，请继续进行天线高度调整"}
            antenna_command = self._generate_antenna_adjustment()
            return [validation_response, antenna_command]
        else:
            # 参数不正确
            print(f"雷达参数验证失败。需要: range={required_range}, scanAngle={required_scan_angle}。收到: range={client_range}, scanAngle={client_scan_angle}")
            validation_response = {"type": "settings_validation", "status": "error", "message": "雷达参数设置不正确，请调整参数"}
            return [validation_response]
    
    async def _handle_antenna_adjusted(self, message: Dict[str, Any], session_state: Dict[str, Any], 
                                     client_event_owner: str) -> Union[Tuple[Dict[str, Any], bool], List[Dict[str, Any]]]:
        """处理天线调整消息"""
        print("消息类型: antenna_adjusted")
        
        validation_response, is_valid = self._handle_antenna_adjustment(message)
        if is_valid:
            if not session_state.get('is_practice', False):
                operation = {
                    'task_id': self.current_session.get('task_id'),
                    'operationType': 'antenna_adjusted',
                    'timestamp': message.get('timestamp', int(time.time() * 1000)),
                    'receive_timestamp': message.get('receive_timestamp'),
                    'isActive': True,
                    'parameters': {'elevation': message.get('elevation')},
                    'user_id': message.get('user_id', ''),
                    'event_owner': client_event_owner
                }
                db_manager.record_operation(operation, session_state.get('is_practice', False))
            else:
                print("练习模式，跳过 antenna_adjusted 数据库记录。")

            return validation_response, True
        else:
            return [validation_response]
    
    async def _handle_target_selected(self, message: Dict[str, Any], session_state: Dict[str, Any], 
                                    client_event_owner: str) -> List[Dict[str, Any]]:
        """处理目标选择消息"""
        print("消息类型: target_selected")
        target_id = message.get('target_id')
        iff_mode = message.get('iff_mode', False)
        
        targets = target_manager.get_targets()
        is_enemy = any(target['id'] == target_id and target['type'] == 'army' for target in targets)
        
        if not session_state.get('is_practice', False):
            operation = {
                'task_id': self.current_session.get('task_id'),
                'operationType': 'target_selected',
                'timestamp': message.get('timestamp', int(time.time() * 1000)),
                'receive_timestamp': message.get('receive_timestamp'),
                'isActive': not iff_mode,
                'parameters': {
                    'target_id': target_id,
                    'action': message.get('action', 'select'),
                    'iff_mode': iff_mode,
                    'is_enemy': is_enemy,
                    'is_correct': (is_enemy and not iff_mode) or False,
                },
                'user_id': message.get('user_id', ''),
                'event_owner': client_event_owner
            }
            db_manager.record_operation(operation, session_state.get('is_practice', False))
        else:
            print("练习模式，跳过 target_selected 数据库记录。")
        
        # 标记雷达目标识别任务完成
        task_manager = session_state.get('task_manager')
        if task_manager:
            task_manager.mark_task_completed()
        
        return []
    
    async def _handle_threat_clicked(self, message: Dict[str, Any], session_state: Dict[str, Any], 
                                   client_event_owner: str) -> List[Dict[str, Any]]:
        """处理威胁点击消息"""
        print("消息类型: threat_clicked")

        if not session_state.get('is_practice', False):
            operation = {
                'task_id': self.current_session.get('task_id'),
                'operationType': 'threat_clicked',
                'timestamp': message.get('timestamp', int(time.time() * 1000)),
                'isActive': True,
                'receive_timestamp': message.get('receive_timestamp'),
                'parameters': {
                    'threat_id': message.get('threat_id'),
                    'label': message.get('label'),
                    'priority': message.get('priority'),
                    'is_highest_priority': message.get('is_highest_priority'),
                    'is_correct': message.get('is_highest_priority', False),
                    'correct_answer': message.get('correct_answer'),
                    'extra': message.get('extra', {})
                },
                'user_id': message.get('user_id', ''),
                'event_owner': client_event_owner
            }
            db_manager.record_operation(operation, session_state.get('is_practice', False))
        else:
            print("练习模式，跳过 threat_clicked 数据库记录。")
        
        # 标记SA威胁应对任务完成
        task_manager = session_state.get('sa_task_manager')
        if task_manager:
            task_manager.mark_task_completed()
        
        return []
    
    async def _handle_record_operation(self, message: Dict[str, Any], session_state: Dict[str, Any], 
                                     client_event_owner: str) -> List[Dict[str, Any]]:
        """处理记录操作消息"""
        print("消息类型: record_operation")
        operation = message.get('operation', {})
        if 'event_owner' not in operation:
            operation['event_owner'] = client_event_owner
        db_manager.record_operation(operation, session_state.get('is_practice', False))
        return []
    
    async def _handle_record_bulk_operations(self, message: Dict[str, Any], session_state: Dict[str, Any], 
                                           client_event_owner: str) -> List[Dict[str, Any]]:
        """处理批量记录操作消息"""
        print("消息类型: record_bulk_operations")
        operations = message.get('operations', [])
        for operation in operations:
            if 'event_owner' not in operation:
                operation['event_owner'] = client_event_owner
            db_manager.record_operation(operation, session_state.get('is_practice', False))
        return []
    
    async def _handle_sa_operations(self, message: Dict[str, Any], session_state: Dict[str, Any], 
                                  websocket) -> List[Dict[str, Any]]:
        """处理SA相关操作"""
        user_id = message.get('user_id')
        if not user_id:
            return [{"type": "error", "message": "Cannot switch SA without a user_id in the message."}]

        task_type = 'SA_THREAT_RESPONSE'
        is_practice = message.get('is_practice', False)
        session_state['is_practice'] = is_practice
        is_ai_active_request = message.get('is_ai_active', False)
        # 为SA任务也创建一个持久化管理器
        task_manager = TaskScenarioManager(config_manager.get_config(), user_id, task_type, is_practice=is_practice, is_ai_active_request=is_ai_active_request)
        session_state['sa_task_manager'] = task_manager
        event_owner = message.get('event_owner', 'manual')
        is_ai_active_request = (event_owner == 'AI')
        
        current_scenario = task_manager.get_next_task_parameters(is_ai_active_request)
        
        if current_scenario == "ALL_COMPLETED":
            return [{"type": "all_tasks_completed", "task_type": task_type, "message": "祝贺！所有SA威胁应对任务已完成。"}]
        if not current_scenario:
            return [{"type": "all_tasks_completed", "task_type": task_type, "message": "当前模式的SA任务已完成。"}]
        task_id = generate_task_id()
        self.current_session['task_id'] = task_id
        self.current_session[f'{task_type}_scenario'] = current_scenario
        
        # 记录操作
        if not session_state.get('is_practice', False):
            operation = {
                'task_id': self.current_session.get('task_id'),
                'operationType': message.get('type'),
                'timestamp': message.get('timestamp', int(time.time() * 1000)),
                'isActive': True,
                'parameters': {},
                'user_id': user_id,
                'event_owner': event_owner
            }
            db_manager.record_operation(operation, session_state.get('is_practice', False))
        
        threats = threat_manager.generate_sa_threats(current_scenario['difficulty_config'])
        
        response = {
            'type': 'sa_task_updated',
            'saThreats': threats,
            'repetition_info': current_scenario['repetition_info'],
            'task_type': task_type,
            'is_ai_active': current_scenario['is_ai_active'],
            'ai_level': current_scenario.get('ai_level_name'),
            'ai_configs': config_manager.get_ai_levels(),
            'audio_enabled': current_scenario['audio_enabled']
        }

        if websocket:
            # 设置当前任务ID到会话状态，供威胁管理器使用
            session_state['current_task_id'] = self.current_session.get('task_id')
            asyncio.create_task(
                threat_manager.auto_send_sa_emergency(
                    websocket,
                    threats,
                    user_id,
                    event_owner,
                    session_state
                )
            )
        return [response]
    
    # async def _handle_reset_targets(self, message: Dict[str, Any], session_state: Dict[str, Any]) -> List[Dict[str, Any]]:
    #     """处理重置目标消息"""
    #     print("消息类型: reset_targets ( advancing scenario counter )")
        
    #     user_id = self.current_session.get('user_id', '')
    #     if not user_id:
    #         return [{"type": "error", "message": "Cannot reset_targets without a user session."}]

    #     task_manager = session_state.get('task_manager')
    #     if not task_manager:
    #         return [{"type": "error", "message": "Task not started. Cannot reset targets."}]

    #     is_ai_active_request = self.current_session.get('RADAR_TARGETING_scenario', {}).get('is_ai_active', False)
    #     event_owner = 'AI' if is_ai_active_request else 'manual'

    #     current_scenario = task_manager.get_next_task_parameters(is_ai_active_request)
    #     if not current_scenario:
    #         return [{"type": "all_tasks_completed", "task_type": "RADAR_TARGETING", "message": "Congratulations! All Radar Targeting scenarios have been completed."}]

    #     self.current_session['RADAR_TARGETING_scenario'] = current_scenario
    #     task_id = generate_task_id()
    #     self.current_session['task_id'] = task_id
        
    #     db_manager.record_task_settings(task_id, current_scenario, user_id, event_owner, session_state.get('is_practice', False))

    #     # 根据新场景重新初始化目标
    #     target_manager.initialize_targets(current_scenario['difficulty_config'])
        
    #     # 构造一个init_settings消息，以便前端可以更新其状态（包括计数器）
    #     response_message = {
    #         "type": "init_settings",
    #         "task_id": task_id,
    #         "timestamp": time.time() * 1000,
    #         "settings": {"range": 80, "scanAngle": 30},
    #         "is_ai_active": current_scenario['is_ai_active'],
    #         "ai_level": current_scenario['ai_level_name'],
    #         "ai_configs": config_manager.get_ai_levels(),
    #         "audio_enabled": current_scenario['audio_enabled'],
    #         "repetition_info": current_scenario['repetition_info'],
    #         "task_type": "RADAR_TARGETING"
    #     }
    #     return [response_message]
    
    def _generate_antenna_adjustment(self) -> Dict[str, Any]:
        """生成随机天线高度指令"""
        # 从-3,-2,-1,1,2,3中随机选择一个调整值
        direction = random.choice([-3, -2, -1, 1, 2, 3])
        target_elevation = direction
        
        # 更新当前会话状态
        self.current_session['target_elevation'] = target_elevation
        self.current_session['stage'] = 'antenna_adjustment'
        
        return {
            "type": "adjust_antenna",
            "targetElevation": target_elevation,
            "message": f"请将天线高度{'上移' if direction > 0 else '下移'} {abs(target_elevation)}格"
        }
    
    def _handle_antenna_adjustment(self, message: Dict[str, Any]) -> Tuple[Dict[str, Any], bool]:
        """处理天线高度调整确认"""
        try:
            client_elevation = message.get('elevation')
            
            # 检查是否在预期范围内（允许±0.1°的误差）
            target_elevation = self.current_session.get('target_elevation')
            
            if target_elevation is None:
                return {
                    "type": "settings_validation",
                    "status": "error",
                    "message": "未找到目标天线高度设置，请重新初始化系统"
                }, False
            
            if abs(client_elevation - target_elevation) <= 0.1:
                # 高度设置正确
                self.current_session['stage'] = 'target_identification'
                print('【调试】天线高度设置正确，开始发送目标数据')
                return {
                    "type": "settings_validation",
                    "status": "success",
                    "message": "天线高度设置正确，开始发送目标数据"
                }, True
            else:
                # 高度设置不正确
                return {
                    "type": "settings_validation",
                    "status": "error",
                    "message": f"天线高度设置不正确，目标为{target_elevation}°，当前为{client_elevation}°"
                }, False
        except Exception as e:
            print(f"天线调整出错: {e}")
            return {"type": "ERROR", "message": f"处理天线调整时出错: {e}"}, False

# 全局消息处理器实例
message_handler = MessageHandler() 